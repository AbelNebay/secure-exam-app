package com.soira.eri_scantron;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.downloader.Error;
import com.downloader.OnCancelListener;
import com.downloader.OnDownloadListener;
import com.downloader.OnPauseListener;
import com.downloader.PRDownloader;
import com.downloader.Status;
import com.soira.eri_scantron.util.Data;
import com.soira.eri_scantron.view.SoiraButton;
import com.soira.eri_scantron.view.SoiraTextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

import static com.soira.eri_scantron.util.Fields.PASSWORD;

public class DownloadDB extends AppCompatActivity {
    int downloadId, download_index;
    OkHttpClient client;

    RelativeLayout wifi_warn;
    SoiraTextView info_text;
    SoiraButton restart_exit;
    ImageView imageView;
    WifiManager wifiManager;

    public boolean checkWifi(Context context) {
        if (wifiManager == null) {
            wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        }
        return wifiManager != null && wifiManager.isWifiEnabled();
    }

    public static String createJson(String[] values) {
        String json_head = "{\n", json_cap = "}";
        String body = "";
        for (String entry : values) {
            String[] data = entry.split(":");
            body += "\"" + data[0] + "\":\"" + data[1] + "\",\n";
        }
        if (body.endsWith(",\n")){
            body = body.substring(0, body.length() - 2) + "\n";
        }
        return json_head + body + json_cap;
    }

    boolean halted = false;
    Call call;
    private void set_request(String post) {
        if (client == null) {
            client = new OkHttpClient();
        }
        FormBody formBody = new FormBody.Builder().add(post.split(":")[0], post.split(":")[1]).build();
        Request request = new Request.Builder().url(Data.GENERAL_URL).post(formBody).build();
        if (call != null){
            call.cancel();
            call = null;
        }
        call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, final IOException e) {
                call.cancel();
                DownloadDB.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        error_message();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (halted)return;
                ResponseBody resp = response.body();
                if (resp != null) {
                    String body = resp.string();
                    if (body == null || body.length() == 0 || body.split(":").length != 2){
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                error_message();
                            }
                        });
                        return;
                    }
                    final String key = body.split(":")[0];
                    final String value = body.split(":")[1];
                    switch (key) {
                        case "db_version":
                            DownloadDB.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (value.equals("null")){
                                        error_message();
                                        return;
                                    }
                                    String info = value.split(",")[0];

                                    String version = strip_version(info);
                                    cloud_version = Integer.valueOf(version);
                                    exam_count = value.split(",")[1].split("#").length;
                                    if (db_expired()) { // value = [version,lists of exams]int,string,string...
                                        editor.putBoolean("REG", false).apply();
                                        download_db(value);
                                    }else if (exam_unavailable()){
                                        download_exams(value.split(",")[1]);
                                    }else {
                                        head_next();
                                    }
                                }
                            });
                            break;
                    }
                }
            }
        });
    }

    private String strip_version(String info) {
        return info.split("\n")[1];
    }

    private boolean exam_unavailable() {
        String download_dir = "/data/data/" + getPackageName() + "/exams";
        File file = new File(download_dir);

        if (!file.exists()){
            return true;
        }
        int count = 0;
        for (File entry: file.listFiles()){
            if (entry.isDirectory()){
                int then = entry.listFiles().length - 3;
                if (then > 0) {
                    count += then;
                }
            }
        }
        return exam_count != count;

    }

    private void head_next() {
        startActivity(new Intent(DownloadDB.this, Intro.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("then", false));
    }

    private void restart_app() {
        startActivity(new Intent(DownloadDB.this, DownloadDB.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("then", false));
    }

    private void download_db(final String value) {
        final String exams_path = value.split(",")[1];
        final String download_dir = "/data/data/" + getPackageName() + "/databases";
        final File download_file = new File(download_dir + File.separator + "STUDENT_DATABASE_ENC.db");

        if (download_file.exists()){
            download_file.delete();
        }
        if (Status.RUNNING == PRDownloader.getStatus(downloadId)){
            PRDownloader.cancel(downloadId);
            return;
        }
        downloadId = PRDownloader.download(Data.DB_URL, download_dir, "STUDENT_DATABASE_ENC.db")
                .build()
                .setOnPauseListener(new OnPauseListener() {
                    @Override
                    public void onPause() {
                        error_message();
                    }
                })
                .setOnCancelListener(new OnCancelListener() {
                    @Override
                    public void onCancel() {
                        error_message();
                    }
                })
                .start(new OnDownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        boolean copied = copy_originals_db(download_file);
                        if (copied){
                            download_file.delete();
                        }
                        closeWarning();
                        editor.putInt(DB_VERSION_PREF, cloud_version).apply();
                        download_exams(exams_path);
                    }

                    @Override
                    public void onError(Error error) {
                        error_message();
                    }
                });

    }

    private void download_exams(String value) {// # splitted
        final String download_dir = "/data/data/" + getPackageName() + "/exams_enc";
        final String copy_dir = "/data/data/" + getPackageName() + "/exams";
        File download_file = new File(download_dir);
        File copy_file = new File(copy_dir);
        if (!download_file.exists() && !download_file.mkdirs()){
            Toast.makeText(this, "Error in downloading exam. Trying again...", Toast.LENGTH_SHORT).show();
            restart_app();
            return;
        }
        for (File entry: download_file.listFiles()){
            entry.delete();
        }
        if (!copy_file.exists() && !copy_file.mkdirs()){
            Toast.makeText(this, "Error in downloading exam. Trying again...", Toast.LENGTH_SHORT).show();
            restart_app();
            return;
        }
        for (File entry: copy_file.listFiles()){
            entry.delete();
        }
        // eng1-#eng2#eng3#math1#math2...
        // Biology - A/Bology_1.png
        for (String exam: value.split("#")){
            String folder_name = exam.split("/")[0];
            String subject_name = exam.split("/")[1];
            String version = folder_name.substring(folder_name.length() - 1);

            String exam_path = Data.EXAM_URL + File.separator + folder_name + File.separator + subject_name;
            subject_name = version.toLowerCase() + subject_name;
            final String sub_name = subject_name;
            download_index = PRDownloader.download(exam_path, download_dir, subject_name)
                    .build()
                    .setOnPauseListener(new OnPauseListener() {
                        @Override
                        public void onPause() {
                            error_message();
                        }
                    })
                    .setOnCancelListener(new OnCancelListener() {
                        @Override
                        public void onCancel() {
                            error_message();
                        }
                    })
                    .start(new OnDownloadListener() {
                        @Override
                        public void onDownloadComplete() {
                            boolean copied = copy_originals_exam(download_dir + File.separator + sub_name, sub_name);
                            if (copied){
                                closeWarning();
                                head_next();
                            }else {
                                error_message();
                            }
                        }

                        @Override
                        public void onError(Error error) {
                            error_message();
                        }
                    });
        }
    }

    private boolean copy_originals_exam(String path, String name) {
        boolean copied = false;
        try{
            String dec_path = "/data/data/" + getPackageName() + "/exams";
            if (!new File(dec_path).exists() && !new File(dec_path).mkdirs()){
                throw new Exception();
            }
            FileInputStream input = new FileInputStream(new File(path));
            FileOutputStream output = new FileOutputStream(new File(dec_path + File.separator + name));
            byte[] capacity = new byte[51200];
            Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(PASSWORD.getBytes(), "AES"), new IvParameterSpec(new byte[16]));
            OutputStream cipherOutput = new CipherOutputStream(output, cipher);
            while (true) {
                int dolly = input.read(capacity);
                if (dolly == -1) break;
                cipherOutput.write(capacity, 0, dolly);
            }
            copied = true;
            cipherOutput.close();
            output.close();
            input.close();
        }catch (Exception ignored){}
        if (copied){
            new File(path).delete();
        }
        return copied;
    }

    private boolean copy_originals_db(File path) {
        boolean copied = false;
        try{
            String dec_path = "/data/data/" + getPackageName() + "/databases";
            FileInputStream input = new FileInputStream(path);
            FileOutputStream output = new FileOutputStream(new File(dec_path + File.separator + "STUDENT_DATABASE.db"));
            byte[] capacity = new byte[51200];
            Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(PASSWORD.getBytes(), "AES"), new IvParameterSpec(new byte[16]));
            OutputStream cipherOutput = new CipherOutputStream(output, cipher);
            while (true) {
                int dolly = input.read(capacity);
                if (dolly == -1) break;
                cipherOutput.write(capacity, 0, dolly);
            }
            copied = true;
            cipherOutput.close();
            output.close();
            input.close();
        }catch (Exception ignored){}
        return copied;
    }

    private void error_message() {
        openWarning("CONNECTION FAILED.\nPLEASE RESTART THE APP.", true, false);
    }

    public static int cloud_version = -1, exam_count = -1;
    private boolean db_expired() {
        String db_path = "/data/data/" + getPackageName() + "/databases/STUDENT_DATABASE.db";
        if (!new File(db_path).exists()){
            return true;
        }else {
            if (DB_VERSION < cloud_version)return true;
        }

        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean exit = getIntent().getBooleanExtra("exit", false);
        if (exit){
            finish();
            return;
        }
        boolean error = getIntent().getBooleanExtra("db_error", false);
        if (error){
            sharedPreferences = getSharedPreferences("VERSION", MODE_PRIVATE);
            editor = sharedPreferences.edit();
            DB_VERSION = sharedPreferences.getInt(DB_VERSION_PREF, -1);
            if (!checkWifi(this)) {
                openWarning("WIFI IS OFF.\nTURN IT ON AND CONNECT TO EXAM HOTSPOT.", false, false);
                return;
            }
            closeWarning();
            requestPermissions();
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (!checkWifi(this)) {
            openWarning("WIFI IS OFF.\nTURN IT ON AND CONNECT TO EXAM HOTSPOT.", false, false);
        }else {
            requestPermissions();
        }
    }

    public static int DB_VERSION = -1;
    public static String DB_VERSION_PREF = "DB_VERSION";
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.download_db);

        init_views();
        init_listeners();

        sharedPreferences = getSharedPreferences("VERSION", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        DB_VERSION = sharedPreferences.getInt(DB_VERSION_PREF, -1);
        if (!checkWifi(this)) {
            openWarning("WIFI IS OFF.\nTURN IT ON AND CONNECT TO EXAM HOTSPOT.", false, false);
            return;
        }
        closeWarning();
        requestPermissions();
    }

    boolean wifi_check = false;
    private void init_listeners() {
        restart_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (last_restart || storage_permission){
                    restart_app();
                }else {
                    wifi_check = true;
                    startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                }
            }
        });
    }

    boolean last_restart = false, storage_permission = false;
    private void openWarning(String message, boolean restart, boolean permission){
        last_restart = restart;
        storage_permission = permission;
        info_text.setText(message);
        wifi_warn.setVisibility(View.VISIBLE);
        if (storage_permission){
            restart_exit.setText("RESTART");
            imageView.setImageResource(R.mipmap.permission);
        }else if (last_restart){
            restart_exit.setText("RESTART");
            imageView.setImageResource(R.mipmap.net_failed);
        }else {
            restart_exit.setText("OPEN WIFI");
            imageView.setImageResource(R.mipmap.wifi_off);
        }
    }

    @Override
    public void onBackPressed() {
        halted = true;
        if (call != null){
            call.cancel();
            call = null;
        }
        super.onBackPressed();
        finish();
    }

    private void closeWarning(){
        info_text.setText("");
        wifi_warn.setVisibility(View.GONE);
    }

    private void init_views() {
        wifi_warn = (RelativeLayout) findViewById(R.id.wifi_warn);
        info_text = (SoiraTextView) findViewById(R.id.info_text);
        restart_exit = (SoiraButton) findViewById(R.id.restart_exit);
        imageView = (ImageView) findViewById(R.id.imageView);
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
        }else {
            set_request("db_version:true");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length == 2 && requestCode == 0) {
            if (grantResults[0] != 0 || grantResults[1] != 0) {
                openWarning("PERMISSION IS REQUIRED.\nPLEASE ALLOW STORAGE ACCESS.", false, true);
            }else {
                set_request("db_version:true");
            }
        }
    }

}
