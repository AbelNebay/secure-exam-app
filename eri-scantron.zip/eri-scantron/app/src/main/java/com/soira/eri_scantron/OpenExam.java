package com.soira.eri_scantron;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.soira.eri_scantron.adapter.ExamRecyclerAdapter;
import com.soira.eri_scantron.interfaces.OnConditionMet;
import com.soira.eri_scantron.util.Data;
import com.soira.eri_scantron.util.LockLayer;
import com.soira.eri_scantron.util.Timer;
import com.soira.eri_scantron.view.SimpleDivider;
import com.soira.eri_scantron.view.SoiraAutoCompleteTextView;
import com.soira.eri_scantron.view.SoiraButton;
import com.soira.eri_scantron.view.SoiraTextView;


import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

import static com.soira.eri_scantron.util.Fields.first;
import static com.soira.eri_scantron.util.Fields.intentional;
import static com.soira.eri_scantron.util.Fields.locked;
import static com.soira.eri_scantron.util.Fields.official_time;
import static com.soira.eri_scantron.util.Fields.selected;
import static com.soira.eri_scantron.util.Fields.selected_answers;
import static com.soira.eri_scantron.util.Fields.time_started;

public class OpenExam extends AppCompatActivity{

    OkHttpClient client;
    WebView paper;
    RelativeLayout confirm_alert, waiting, wifi_warn, data_holder;
    SoiraTextView timer, subject_print, info_scantron;
    ImageView scantron_view;
    private LockLayer lockLayer;
    RelativeLayout open_exam_layout, password_alert;
    RecyclerView recyclerView;
    SoiraAutoCompleteTextView password_text;
    HorizontalScrollView horizontalScrollView;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    PowerManager powerManager;
    PowerManager.WakeLock wakeLock;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (!intentional){
            Intent intent = new Intent(OpenExam.this, OpenExam.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        if (first){
            first = false;
            init();
            return;
        }
        if (!intentional){
            return;
        }
        init();
    }

    private void send_answers(){
        String whole = "";
        if (selected_answers == null){
            selected_answers = new String[exam_length];
        }
        for (String entry: selected_answers){
            if (entry == null){
                entry = "x";
            }
            whole += entry + ",";
        }
        whole = whole.substring(0, whole.length() - 5);
        // A,B,D,E,A,B,C,C,...
        String subject_name = subject + " - " + subject_version;
        set_request("finish_exam:" + subject_name + "#" + information.replaceAll(":", "#") + "#" + whole);
    }

    boolean waiting_halted = false;
    Runnable waiting_runner = new Runnable() {
        @Override
        public void run() {
            if (!waiting_halted) {
                waiting.setVisibility(View.VISIBLE);
            }
        }
    };
    Handler waiting_handler;
    Call call;
    private void set_request(String post) {
        waiting_halted = false;
        if (waiting_handler != null){
            waiting_handler.removeCallbacks(waiting_runner);
            waiting_handler = null;
        }
        waiting_handler = new Handler();
        waiting_handler.postDelayed(waiting_runner, 1000);
        if (client != null) {
            client = null;
        }
        client = new OkHttpClient();

        FormBody formBody = new FormBody.Builder().add(post.split(":")[0], post.split(":")[1]).build();
        Request request = new Request.Builder().url(Data.GENERAL_URL).post(formBody).build();
        if (call != null){
            call.cancel();
            call = null;
        }
        call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, final IOException e) {
                waiting_halted = true;
                if (waiting_handler != null){
                    waiting_handler.removeCallbacks(waiting_runner);
                    waiting_handler = null;
                }
                OpenExam.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        waiting.setVisibility(View.GONE);
                        error_message();
                    }
                });
                call.cancel();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                waiting_halted = true;
                ResponseBody resp = response.body();
                if (resp != null) {
                    String body = resp.string();
                    if (body == null || body.length() == 0 || body.split(":").length != 2){
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                error_message();
                            }
                        });
                        return;
                    }
                    String key = body.split(":")[0];
                    final String value = body.split(":")[1]; // ENGLISH,A,60,5#4#4

                    switch (key) {
                        case "finish_exam":
                            OpenExam.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    waiting.setVisibility(View.GONE);
                                    if (value.equals("thank_you")){
                                        thank_you();
                                        return;
                                    }
                                    close_password();
                                    error_message();
                                }
                            });
                            break;
                    }
                }
            }
        });
    }

    private void thank_you() {
        if (lockLayer != null) {
            lockLayer.unlock();
        }
        if (selected != null){
            selected.clear();
        }
        if (selected_answers != null){
            selected_answers = null;
        }
        first = true;
        intentional = true;
        try {
            Toast.makeText(this, "Thank you for your participation.", Toast.LENGTH_SHORT).show();
            handler.removeCallbacks(runnable);
        }catch (Exception ignored){}
        startActivity(new Intent(OpenExam.this, DownloadDB.class).putExtra("exit", true).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
        if (powerManager != null && wakeLock != null){
            if (wakeLock.isHeld()){
                wakeLock.release();
            }
        }
    }

    private void error_message() {
        openWarning("CONNECTION FAILED.\nPLEASE RESTART THE APP.");
    }

    private void openWarning(String message){
        warning = true;
        wifi_warn.setVisibility(View.VISIBLE);
    }

    private void closeWarning() {
        warning = false;
        wifi_warn.setVisibility(View.GONE);
    }

    boolean qr_opened = false, warning = false;

    private void open_qr_null() {
        qr_opened = true;
        String whole = "";
        if (selected_answers == null){
            selected_answers = new String[exam_length];
        }
        for (String entry: selected_answers){
            if (entry == null){
                entry = "x";
            }
            whole += entry + ",";
        }
        whole = whole.substring(0, whole.length() - 1);

    }

    private void close_qr() {
        if (locked)return;
        qr_opened = false;
    }

    private void apply_delta() {
        open_exam_layout.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int visibility) {
                full_screen();
            }
        });
    }

    private void full_screen(){
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//            open_exam_layout.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN |
//                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
//                    View.SYSTEM_UI_FLAG_IMMERSIVE |
//                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
//                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
//                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//            );
//        }else {
//            Toast.makeText(this, "This exam is not allowed in this device.", Toast.LENGTH_SHORT).show();
//        }
    }

    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (!locked) {
                long timer_lapse = System.currentTimeMillis() - time_started;
                long timer_left = official_time - timer_lapse;
                timer.setText(Timer.timing(timer_left));
                if (timer_left <= 0) {
                    handler.removeCallbacks(runnable);
                    handler = null;
                    timer.setText("Time is up!");
                    locked = true;
                    send_answers();
                    return;
                }
            }
            try {
                Intent closeStatus = new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
                sendBroadcast(closeStatus);
                handler.postDelayed(this, 10);
            }catch (Exception ignored){}
        }
    };

    private void define_design() {
        int height = getWindowManager().getDefaultDisplay().getHeight() - data_holder.getLayoutParams().height;
        ViewGroup.LayoutParams paperLayoutParams = paper.getLayoutParams();
        ViewGroup.LayoutParams recyclerViewLayoutParams = horizontalScrollView.getLayoutParams();
        paperLayoutParams.height = (int) (height * 0.7);
        recyclerViewLayoutParams.height = (int) (height * 0.3);

        paper.setLayoutParams(paperLayoutParams);
        horizontalScrollView.setLayoutParams(recyclerViewLayoutParams);
    }

    String subject = null, subject_timeout = null, information = null, report_code = null;
    public static String subject_version = null;
    private void init() {
        if (!check_exam()){
            Toast.makeText(this, "Error occurred. Please try again!", Toast.LENGTH_SHORT).show();
            thank_you();
            return;
        }
        View lockView = View.inflate(this, R.layout.open_exam, null);
        lockView.setKeepScreenOn(true);
        lockLayer = LockLayer.getInstance(this);
        lockLayer.setLockView(lockView);
        lockLayer.lock();

        sharedPreferences = getSharedPreferences("DATA", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        paper = (WebView) lockView.findViewById(R.id.paper);
        password_alert = (RelativeLayout) lockView.findViewById(R.id.password_alert);
        open_exam_layout = (RelativeLayout) lockView.findViewById(R.id.open_exam_layout);
        confirm_alert = (RelativeLayout) lockView.findViewById(R.id.confirm_alert);
        waiting = (RelativeLayout) lockView.findViewById(R.id.wait);
        wifi_warn = (RelativeLayout) lockView.findViewById(R.id.wifi_warn);
        data_holder = (RelativeLayout) lockView.findViewById(R.id.data_holder);

        timer = (SoiraTextView) lockView.findViewById(R.id.timer);
        subject_print = (SoiraTextView) lockView.findViewById(R.id.subject);
        info_scantron = (SoiraTextView) lockView.findViewById(R.id.info_scantron);
        scantron_view = (ImageView) lockView.findViewById(R.id.imageView3);
        recyclerView = (RecyclerView) lockView.findViewById(R.id.recycler_view);
        password_text = (SoiraAutoCompleteTextView) lockView.findViewById(R.id.password_text);
        horizontalScrollView = (HorizontalScrollView) lockView.findViewById(R.id.scroller_choice);

        powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.FULL_WAKE_LOCK, "EXAM_WAKE");

        confirm_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Nothing...
            }
        });

        waiting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Nothing...
            }
        });

        wifi_warn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Nothing...
            }
        });

        handler.postDelayed(runnable, 10);
        full_screen();
        apply_delta();
        start_exam();

    }

    private void start_exam() {
        String version = subject_version.equals("A") ? " - Version A" : " - Version B";
        subject_print.setText(subject + version);
        WebSettings webSettings = paper.getSettings();
        webSettings.setJavaScriptEnabled(false);
        paper.getSettings().setBuiltInZoomControls(true);
        if (android.os.Build.VERSION.SDK_INT >= 11){
            paper.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            paper.getSettings().setDisplayZoomControls(false);
        }

        StringBuilder data = new StringBuilder();

        String path_prefix = "file:////data/data/" + getPackageName() + "/exams/";
        data.append("<html>");
        String[] images = html_data.split(":");
        for (String entry: images){
            data.append("<img style=\"width:100%;\" src=\"");
            data.append(path_prefix);
            data.append(entry);
            data.append("\" /><br>");
        }
        data.append("</html>");

        paper.loadDataWithBaseURL(null, data.toString(), "text/html", "UTF-8", null);

        ArrayList<String> values = new ArrayList<>();

        String[] forms = subject_form.split("#");
        exam_length = forms.length;

        values.add("2:0:6");
        for (int i = 1; i <= exam_length; i++){
            values.add("0:" + String.valueOf(i) + ":" + forms[i - 1]);
        }

        values.add("1:0:1");
        examRecyclerAdapter = new ExamRecyclerAdapter(this, values, new OnConditionMet() {
            @Override
            public void onConditionMet(int id) {
                open_confirm();
            }

            @Override
            public void onConditionMet(String id) {

            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new SimpleDivider(this));
        recyclerView.setAdapter(examRecyclerAdapter);
        time_started = System.currentTimeMillis();

        define_design();
        if (powerManager != null && wakeLock != null){
            if (!wakeLock.isHeld() && getClass().getSimpleName().equals("OpenExam")){
                wakeLock.acquire();
            }
        }
    }

    ExamRecyclerAdapter examRecyclerAdapter;
    String html_data = null, subject_form = null;
    int exam_length = 0;
    private boolean check_exam() {
        if (getIntent() != null){
            // ENGLISH,A,60,5#4#4 || null,0021

            subject = getIntent().getStringExtra("subject");
            subject_version = getIntent().getStringExtra("version");
            subject_timeout = getIntent().getStringExtra("timeout");
            subject_form = getIntent().getStringExtra("form");
            information = getIntent().getStringExtra("information");
            report_code = getIntent().getStringExtra("report");
        }
        if (report_code == null || subject == null || subject_version == null || subject_timeout == null || information == null){
            Toast.makeText(this, "No valid subject is selected.", Toast.LENGTH_SHORT).show();
            finish();
            return false;
        }
        String version = subject_version.equals("A") ? "a" : "b";
        String path = "/data/data/" + getPackageName() + "/exams";

        html_data = Data.fetchSubjects(path, version, subject);//Data.HTML.ENGLISH; // by looping get all files that starts with eng + version optionally

        // aENGLISH_1,aENGLISH_2...
        if (html_data == null){
            Toast.makeText(this, "No valid subject or form is selected.", Toast.LENGTH_SHORT).show();
            finish();
            return false;
        }

        official_time = Data.fetchOfficialTime(subject_timeout);
        return true;
    }


    boolean confirm_opened = false;
    private void open_confirm() {
        confirm_opened = true;
        confirm_alert.setVisibility(View.VISIBLE);
    }

    private void close_confirm(){
        confirm_opened = false;
        confirm_alert.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        if (confirm_opened){
            close_confirm();
            return;
        }
        if (warning){
            closeWarning();
            return;
        }
        if (qr_opened){
            if (locked)return;
            close_qr();
            return;
        }
        if (call != null){
            call.cancel();
            call = null;
        }
        super.onBackPressed();

    }

    public void close_confirm(View view) {
        close_confirm();
    }

    public void retry(View view) {
        closeWarning();
        send_answers();
    }

    public void finish_exam(View view) {
        close_confirm();
        send_answers();
    }

    public void close_warn(View view) {
        closeWarning();
    }

    int previous_height = 0;
    public void hide_scantron(View view) {
        ViewGroup.LayoutParams params = horizontalScrollView.getLayoutParams();
        if (params.height != 0) {
            previous_height = params.height;
            params.height = 0;
            scantron_view.setImageResource(R.mipmap.show_scantron);
            info_scantron.setText("Show Scantron");
        }else {
            params.height = previous_height;
            scantron_view.setImageResource(R.mipmap.hide_scantron);
            info_scantron.setText("Hide Scantron");
        }
        horizontalScrollView.setLayoutParams(params);
    }

    public void open_password() {
        password_alert.setVisibility(View.VISIBLE);
    }

    public void close_password() {
        password_text.setText("");
        password_alert.setVisibility(View.GONE);
    }

    public void do_nothing(View view) {
        // Nothing is done for sure...

    }

    public void button_clicked(View view) {
        String already = password_text.getText().toString();
        switch (view.getId()) {
            case R.id.del:
                int len = already.length();
                if (len > 0) {
                    password_text.setText(already.substring(0, len - 1));
                }
                break;
            case R.id.cc:
                password_text.setText("");
                break;
            default:
                password_text.setText(already + ((SoiraButton)view).getText().toString());
        }
        String pass = password_text.getText().toString();
        if (report_code != null && pass.equals(report_code)){

            String whole = "";
            if (selected_answers == null){
                selected_answers = new String[exam_length];
            }
            for (String entry: selected_answers){
                if (entry == null){
                    entry = "x";
                }
                whole += entry + ",";
            }
            whole = whole.substring(0, whole.length() - 1);
            // A,B,D,E,A,B,C,C,...
            String subject_name = subject + " - " + subject_version;

            editor.putString("ANSWERS", subject_name + "#" + information.replaceAll(":", "#") + "#" + whole).apply();
            close_password();
            thank_you();
        }
    }

    public void report(View view) {
        closeWarning();
        open_password();
    }

    public void close_password(View view) {
        close_password();
    }
}
