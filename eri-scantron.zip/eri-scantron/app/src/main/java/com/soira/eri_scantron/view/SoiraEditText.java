package com.soira.eri_scantron.view;


import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.EditText;

public class SoiraEditText extends EditText{

    private void establishFont(){
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "soira_font.ttf"));
    }
    
    public SoiraEditText(Context context) {
        super(context);
        establishFont();
        
    }

    public SoiraEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        establishFont();
        
    }

    public SoiraEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        establishFont();
        
    }

}
