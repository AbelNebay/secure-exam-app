package com.soira.eri_scantron.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.RelativeLayout;

import com.soira.eri_scantron.OpenExam;
import com.soira.eri_scantron.R;
import com.soira.eri_scantron.interfaces.OnConditionMet;
import com.soira.eri_scantron.view.SoiraButton;
import com.soira.eri_scantron.view.SoiraTextView;

import java.util.ArrayList;

import static com.soira.eri_scantron.util.Fields.selected;
import static com.soira.eri_scantron.util.Fields.selected_answers;

public class ExamRecyclerAdapter extends RecyclerView.Adapter<ExamRecyclerAdapter.ViewHolder> {

    private ArrayList<String> path_lists;
    private OnConditionMet onConditionMet;

    private void fire_condition(int media){
        if (onConditionMet == null){
            return;
        }
        onConditionMet.onConditionMet(media);
    }

    private Context context;

    public ArrayList<String> getArrays(){
        return this.path_lists;
    }

    public ExamRecyclerAdapter(Context context, ArrayList<String> path_lists, OnConditionMet onConditionMet) {
        this.context = context;
        this.path_lists = path_lists;
        this.onConditionMet = onConditionMet;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        SoiraTextView question_number;
        SoiraButton welcome, finish;
        RelativeLayout radiogroup;
        SoiraTextView cha, chb, chc, chd, che, chf;

        ViewHolder(@NonNull View v) {
            super(v);
            question_number = (SoiraTextView) v.findViewById(R.id.question_number);
            welcome = (SoiraButton) v.findViewById(R.id.welcome_button);
            finish = (SoiraButton) v.findViewById(R.id.finish_button);

            radiogroup = (RelativeLayout) v.findViewById(R.id.radioGroup);

            cha = (SoiraTextView) v.findViewById(R.id.cha);
            chb = (SoiraTextView) v.findViewById(R.id.chb);
            chc = (SoiraTextView) v.findViewById(R.id.chc);
            chd = (SoiraTextView) v.findViewById(R.id.chd);
            che = (SoiraTextView) v.findViewById(R.id.che);
            chf = (SoiraTextView) v.findViewById(R.id.chf);


        }
        void setData(@NonNull final ArrayList<String> medias, final int position) {
            if (selected == null){
                selected = new ArrayList<>();
            }
            if (selected_answers == null){
                selected_answers = new String[getItemCount()];
            }
            String value = medias.get(position);

            String key = value.split(":")[0];
            if (key.equals("1")){
                question_number.setVisibility(View.GONE);
                radiogroup.setVisibility(View.GONE);
                finish.setVisibility(View.VISIBLE);
                finish.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        fire_condition(0);
                    }
                });
                return;
            }

            if (key.equals("2")){
                radiogroup.setVisibility(View.INVISIBLE);
                question_number.setVisibility(View.INVISIBLE);
                cha.setVisibility(View.INVISIBLE);
                chb.setVisibility(View.INVISIBLE);
                chc.setVisibility(View.INVISIBLE);
                chd.setVisibility(View.INVISIBLE);
                che.setVisibility(View.INVISIBLE);
                chf.setVisibility(View.INVISIBLE);

                finish.setVisibility(View.GONE);
                finish.setOnClickListener(null);
                welcome.setVisibility(View.VISIBLE);
                welcome.setOnClickListener(null);
                return;
            }

            question_number.setVisibility(View.VISIBLE);
            radiogroup.setVisibility(View.VISIBLE);
            finish.setVisibility(View.GONE);
            finish.setOnClickListener(null);
            welcome.setVisibility(View.GONE);
            welcome.setOnClickListener(null);
            String number = value.split(":")[1];
            int form = Integer.valueOf(value.split(":")[2]);

            cha.setVisibility(View.VISIBLE);
            chb.setVisibility(View.VISIBLE);
            chc.setVisibility(View.VISIBLE);
            chd.setVisibility(View.VISIBLE);
            che.setVisibility(View.VISIBLE);
            chf.setVisibility(View.VISIBLE);

            if (form == 1){
                chb.setVisibility(View.INVISIBLE);
                chc.setVisibility(View.INVISIBLE);
                chd.setVisibility(View.INVISIBLE);
                che.setVisibility(View.INVISIBLE);
                chf.setVisibility(View.INVISIBLE);
            }else if (form == 2){
                chc.setVisibility(View.INVISIBLE);
                chd.setVisibility(View.INVISIBLE);
                che.setVisibility(View.INVISIBLE);
                chf.setVisibility(View.INVISIBLE);
            }else if (form == 3){
                chd.setVisibility(View.INVISIBLE);
                che.setVisibility(View.INVISIBLE);
                chf.setVisibility(View.INVISIBLE);
            }else if (form == 4){
                che.setVisibility(View.INVISIBLE);
                chf.setVisibility(View.INVISIBLE);
            }else if (form == 5){
                chf.setVisibility(View.INVISIBLE);
            }

            cha.setChecked(false);
            chb.setChecked(false);
            chc.setChecked(false);
            chd.setChecked(false);
            che.setChecked(false);
            chf.setChecked(false);
            if (selected.contains(number + ":A")){
                cha.setChecked(true);
            }else if (selected.contains(number + ":B")){
                chb.setChecked(true);
            }else if (selected.contains(number + ":C")){
                chc.setChecked(true);
            }else if (selected.contains(number + ":D")){
                chd.setChecked(true);
            }else if (selected.contains(number + ":E")){
                che.setChecked(true);
            }else if (selected.contains(number + ":F")){
                chf.setChecked(true);
            }

            question_number.setText(number + ".");

            final String f_num = number;
            cha.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (v.getVisibility() == View.INVISIBLE){
                        return;
                    }
                    revert_all(f_num);
                    String form = f_num + ":A";
                    selected.add(form);
                    selected_answers[Integer.valueOf(f_num) - 1] = "A";
                    cha.setChecked(false);
                    chb.setChecked(false);
                    chc.setChecked(false);
                    chd.setChecked(false);
                    che.setChecked(false);
                    chf.setChecked(false);

                    cha.setChecked(true);
                }
            });

            chb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (v.getVisibility() == View.INVISIBLE){
                        return;
                    }
                    revert_all(f_num);
                    String form = f_num + ":B";
                    selected.add(form);
                    selected_answers[Integer.valueOf(f_num) - 1] = "B";

                    cha.setChecked(false);
                    chb.setChecked(false);
                    chc.setChecked(false);
                    chd.setChecked(false);
                    che.setChecked(false);
                    chf.setChecked(false);

                    chb.setChecked(true);
                }
            });

            chc.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (v.getVisibility() == View.INVISIBLE){
                        return;
                    }
                    revert_all(f_num);
                    String form = f_num + ":C";
                    selected.add(form);
                    selected_answers[Integer.valueOf(f_num) - 1] = "C";

                    cha.setChecked(false);
                    chb.setChecked(false);
                    chc.setChecked(false);
                    chd.setChecked(false);
                    che.setChecked(false);
                    chf.setChecked(false);

                    chc.setChecked(true);
                }
            });

            chd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (v.getVisibility() == View.INVISIBLE){
                        return;
                    }
                    revert_all(f_num);
                    String form = f_num + ":D";
                    selected.add(form);
                    selected_answers[Integer.valueOf(f_num) - 1] = "D";

                    cha.setChecked(false);
                    chb.setChecked(false);
                    chc.setChecked(false);
                    chd.setChecked(false);
                    che.setChecked(false);
                    chf.setChecked(false);

                    chd.setChecked(true);
                }
            });

            che.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (v.getVisibility() == View.INVISIBLE){
                        return;
                    }
                    revert_all(f_num);
                    String form = f_num + ":E";
                    selected.add(form);
                    selected_answers[Integer.valueOf(f_num) - 1] = "E";

                    cha.setChecked(false);
                    chb.setChecked(false);
                    chc.setChecked(false);
                    chd.setChecked(false);
                    che.setChecked(false);
                    chf.setChecked(false);

                    che.setChecked(true);
                }
            });

            chf.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (v.getVisibility() == View.INVISIBLE){
                        return;
                    }
                    revert_all(f_num);
                    String form = f_num + ":F";
                    selected.add(form);
                    selected_answers[Integer.valueOf(f_num) - 1] = "F";

                    cha.setChecked(false);
                    chb.setChecked(false);
                    chc.setChecked(false);
                    chd.setChecked(false);
                    che.setChecked(false);
                    chf.setChecked(false);

                    chf.setChecked(true);
                }
            });

        }
    }

    private void revert_all(String number) {
        String a_val = number + ":A", b_val = number + ":B", c_val = number + ":C", d_val = number + ":D", e_val = number + ":E", f_val = number + ":F";

        selected.remove(a_val);
        selected.remove(b_val);
        selected.remove(c_val);
        selected.remove(d_val);
        selected.remove(e_val);
        selected.remove(f_val);
    }

    @NonNull
    @Override
    public ExamRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.exam_question_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.setData(this.path_lists, position);
    }

    @Override
    public void onViewAttachedToWindow(ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
    }

    @Override
    public int getItemCount() {
        return this.path_lists.size();
    }

}