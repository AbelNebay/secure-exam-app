package com.soira.eri_scantron;

import android.Manifest;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;


import java.io.File;


import static com.soira.eri_scantron.DownloadDB.DB_VERSION;
import static com.soira.eri_scantron.DownloadDB.cloud_version;

public class Intro extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onPause() {
        super.onPause();
//        try{
//            unregisterReceiver(receiver);
//        }catch (Exception ignored){}
    }

    boolean permission_granted = false;
    @Override
    protected void onResume() {
        super.onResume();
        boolean then = getIntent().getBooleanExtra("exit", false);
        if (then){
            finish();
            return;
        }
        if (!permission_granted){
            requestPermissions();
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            if (!Settings.canDrawOverlays(this)){
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 5);
                return;
            }
        }
//        registerReceiver(receiver, new IntentFilter(Intent.ACTION_BOOT_COMPLETED));
        head_next();

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length == 3 && requestCode == 0) {
            if (grantResults[0] != 0 || grantResults[1] != 0 || grantResults[2] != 0) {
                Toast.makeText(this, "Permission is required!", Toast.LENGTH_SHORT).show();
                requestPermissions();
                return;
            }
            permission_granted = true;
            try {
                init_db();
            } catch (Exception e) {}
        }
    }

    private void init_db() throws Exception {
        String path = "/data/data/" + getPackageName() + "/databases/STUDENT_DATABASE.db";
        if (permission_granted && (!new File(path).exists() || cloud_version > DB_VERSION)){
            editor.putBoolean("REG", false).apply();
            Toast.makeText(this, "Valid database was not found.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(Intro.this, DownloadDB.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("db_error", true));
        }
    }

    private void requestPermissions(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, 0);
        }
    }


//    OpenExamBootReceiver receiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.intro);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions();
        }
        sharedPreferences = getSharedPreferences("ABEL", MODE_PRIVATE);
        editor = sharedPreferences.edit();
//        if (receiver == null){
//            receiver = new OpenExamBootReceiver();
//        }
    }


    private void head_next() {
        boolean registered = sharedPreferences.getBoolean("REG", false);
        if (!registered){
            open_registry();
            return;
        }
        startActivity(new Intent(Intro.this, ExamSheet.class));
    }

    private void open_registry() {
        startActivity(new Intent(Intro.this, AddStudent.class));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();

    }
}
