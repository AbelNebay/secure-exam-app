package com.soira.eri_scantron.interfaces;


import java.io.File;

public interface OnExplorerMet {

    void onFound(String file);

    void onExplorer(File[] media);

}
