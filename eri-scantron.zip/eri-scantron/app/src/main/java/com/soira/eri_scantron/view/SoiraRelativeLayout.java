package com.soira.eri_scantron.view;


import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;


public class SoiraRelativeLayout extends RelativeLayout{

    public SoiraRelativeLayout(Context context) {
        super(context);
    }

    public SoiraRelativeLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SoiraRelativeLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

}
