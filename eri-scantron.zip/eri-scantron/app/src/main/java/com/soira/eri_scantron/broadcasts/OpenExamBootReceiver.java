package com.soira.eri_scantron.broadcasts;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.soira.eri_scantron.Intro;

public class OpenExamBootReceiver extends BroadcastReceiver{

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && intent.getAction() != null && intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)){
            Intent openExam = new Intent(context, Intro.class);
            openExam.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(openExam);
        }
    }
}
