package com.soira.eri_scantron.util;


import com.soira.eri_scantron.OpenExam;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

public class Data {

    private static final String MAIN_PORT = "8080";

    private static final String MAIN_URL = "http://192.168.43.1:" + MAIN_PORT + "/";

    public static final String GENERAL_URL = MAIN_URL + "introduction.php";

    public static final String DB_URL = MAIN_URL + "database/student_database.db";
    public static final String IMAGE_URL = MAIN_URL + "database/images";
    public static final String EXAM_URL = MAIN_URL + "exams";

    public static String fetchSubjects(String path, String version, String subject) {
        // path = data/data/com.soira.eri_scantron/exams & subject = aBiology
        File file = new File(path);
        if (!file.exists()){
            return null;
        }
        ArrayList<String> exam = new ArrayList<>();
        for (File entry: file.listFiles()){
            String name = entry.getName();
            if (name.startsWith(version + subject) && name.endsWith(".png")){
                exam.add(name);
            }
        }
        if (exam.isEmpty()){
            if (version.equals("a")){
                version = "b";
            }else {
                version = "a";
            }
            for (File entry: file.listFiles()){
                String name = entry.getName();
                if (name.startsWith(version + subject) && name.endsWith(".png")){
                    exam.add(name);
                }
            }
            if (!exam.isEmpty()){
                OpenExam.subject_version = version.toUpperCase();
            }
        }
        if (exam.isEmpty()){
            return null;
        }

        Collections.sort(exam);
        String formatted = "";
        for (String entry: exam){
            formatted += entry + ":";
        }
        if (formatted.isEmpty()){
            return null;
        }
        formatted = formatted.substring(0, formatted.length() - 1);
        return formatted;
    }

    public static long fetchOfficialTime(String subject_timeout) {
        return Long.valueOf(subject_timeout) * 60000L;
    }

    public class HTML{

        public static final String ENGLISH = "eng:eng2:eng3:eng4";

        public static final String MATHEMATICS = "math:math2";

        public static final String BIOLOGY = "bio:bio2:bio3:bio4";

        public static final String CHEMISTRY = "chem:chem2";

        public static final String PHYSICS = "phy:phy2";

    }

    public class ENGLISH{

        public static final long TIMER = 60 * 60000;

        public static final String FORM_A = "5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5";

        public static final String FORM_B = "5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5";

    }

    public class MATHEMATICS{

        public static final long TIMER = 60 * 60000;

        public static final String FORM_A = "5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,4,4,4,5";

        public static final String FORM_B = "5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,4,4,4,5";

    }

    public class BIOLOGY{

        public static final long TIMER = 60 * 60000;

        public static final String FORM_A = "5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5";

        public static final String FORM_B = "5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5";

    }

    public class CHEMISTRY{

        public static final long TIMER = 60 * 60000;

        public static final String FORM_A = "5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5";

        public static final String FORM_B = "5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5";

    }

    public class PHYSICS{

        public static final long TIMER = 60 * 60000;

        public static final String FORM_A = "5,5,5,5,4,5,5,5,5,5,5,5,5,5,5,5,5,5,5,4";

        public static final String FORM_B = "5,5,5,5,4,5,5,5,5,5,5,5,5,5,5,5,5,5,5,4";

    }

}
