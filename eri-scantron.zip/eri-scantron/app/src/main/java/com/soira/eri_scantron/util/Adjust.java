package com.soira.eri_scantron.util;



public class Adjust {

    public static float adjust(float x, float inMin, float inMax, float outMin, float outMax){
        float outRange = outMax - outMin;
        float inRange = inMax - inMin;
        return (x - inMin) * outRange / inRange + outMin;

    }
}
