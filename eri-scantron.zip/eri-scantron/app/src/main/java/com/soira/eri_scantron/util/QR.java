package com.soira.eri_scantron.util;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.Display;
import android.view.WindowManager;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.reedsolomon.a;

import java.util.EnumMap;
import java.util.Map;

import static android.content.Context.WINDOW_SERVICE;

public class QR {

    public static final int WALL = 1;
    public static final int SALES = 0;

    public static int TARGET = -1;


    static final class QRCodeEncoder {
        private static final int WHITE = 0xFFFFFFFF;
        private static final int BLACK = 0xFF000000;

        private int dimension = Integer.MIN_VALUE;
        @Nullable
        private String contents = null;
        @Nullable
        private String title = null;
        @Nullable
        private BarcodeFormat format = null;
        private boolean encoded = false;

        QRCodeEncoder(String data, @NonNull String type, String format, int dimension) {
            this.dimension = dimension;
            encoded = encodeContents(data, type, format);
        }

        @Nullable
        public String getContents() {
            return contents;
        }

        @Nullable
        public String getTitle() {
            return title;
        }

        private boolean encodeContents(@Nullable String data, @NonNull String type, @Nullable String formatString) {
            // Default to QR_CODE if no format given.
            format = null;
            if (formatString != null) {
                try {
                    format = BarcodeFormat.valueOf(formatString);
                } catch (IllegalArgumentException iae) {
                    // Ignore it then
                }
            }
            if (format == null || format == BarcodeFormat.QR_CODE) {
                this.format = BarcodeFormat.QR_CODE;
                encodeQRCodeContents(data, type);
            } else if (data != null && data.length() > 0) {
                contents = data;
                title = "Text";
            }
            return contents != null && contents.length() > 0;
        }

        private void encodeQRCodeContents(@Nullable String data, @NonNull String type) {
            if (type.equals(Contents.Type.TEXT)) {
                if (data != null && data.length() > 0) {
                    contents = data;
                    title = "Text";
                }
            }

        }

        Bitmap encodeAsBitmap() throws WriterException {
            if (!encoded) return null;

            Map<EncodeHintType, Object> hints = null;
            String encoding = guessAppropriateEncoding(contents);
            if (encoding != null) {
                hints = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
                hints.put(EncodeHintType.CHARACTER_SET, encoding);
            }
            MultiFormatWriter writer = new MultiFormatWriter();
            BitMatrix result = writer.encode(contents, format, dimension, dimension, hints);
            int width = result.getWidth();
            int height = result.getHeight();
            int[] pixels = new int[width * height];
            // All are 0, or black, by default
            for (int y = 0; y < height; y++) {
                int offset = y * width;
                for (int x = 0; x < width; x++) {
                    pixels[offset + x] = result.get(x, y) ? BLACK : WHITE;
                }
            }

            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
            return bitmap;
        }

        private static String guessAppropriateEncoding(@NonNull CharSequence contents) {
            // Very crude at the moment
            for (int i = 0; i < contents.length(); i++) {
                if (contents.charAt(i) > 0xFF) {
                    return "UTF-8";
                }
            }
            return null;

        }

    }

    static final class Contents {
        private Contents() {
        }

        static final class Type {

            static final String TEXT = "TEXT_TYPE";

            private Type() {
            }
        }
    }

    @Nullable
    public static Bitmap generate(@NonNull Context context, @Nullable String value) {
        if (value == null) {
            return null;
        }
        value = a.qal(value);
        Bitmap bitmap = null;
        WindowManager manager = (WindowManager) context.getSystemService(WINDOW_SERVICE);
        Display display = manager.getDefaultDisplay();
        Point point = new Point();
        display.getSize(point);
        int width = point.x;
        int height = point.y;
        int smallerDimension = width < height ? width : height;
        smallerDimension = smallerDimension * 3 / 4;

        // Encode with setting_layout QR Code image
        QRCodeEncoder qrCodeEncoder = new QRCodeEncoder(value,
                Contents.Type.TEXT,
                BarcodeFormat.QR_CODE.toString(),
                smallerDimension);
        try {
            bitmap = qrCodeEncoder.encodeAsBitmap();

        } catch (WriterException e) {
            e.printStackTrace();
        }
        return bitmap;
    }

}
