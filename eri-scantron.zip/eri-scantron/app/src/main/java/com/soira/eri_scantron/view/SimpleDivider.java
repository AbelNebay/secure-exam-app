package com.soira.eri_scantron.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.soira.eri_scantron.R;

public class SimpleDivider extends RecyclerView.ItemDecoration {

    private Drawable mDivider;
    public SimpleDivider(Context context) {
        mDivider = context.getResources().getDrawable(R.drawable.divider_blue);
    }

    @Override public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
        //divider padding give some padding whatever u want or disable
        int left = parent.getPaddingLeft() + 0;//80;
        int right = parent.getWidth() - parent.getPaddingRight() - 0;//30;
        int childCount = parent.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View child = parent.getChildAt(i);
            RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child.getLayoutParams();
            int top = child.getBottom() + params.bottomMargin;
            int bottom = top + mDivider.getIntrinsicHeight();
            mDivider.setBounds(left, top, right, bottom);
            mDivider.draw(c);

        }
    }
}

