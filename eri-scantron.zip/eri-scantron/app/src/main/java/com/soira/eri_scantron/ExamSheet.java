package com.soira.eri_scantron;


import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.downloader.Error;
import com.downloader.OnCancelListener;
import com.downloader.OnDownloadListener;
import com.downloader.OnPauseListener;
import com.downloader.PRDownloader;
import com.face.ScanFace;
import com.face.utils.FaceRegister;
import com.soira.eri_scantron.keyboard.SoftKeypax;
import com.soira.eri_scantron.util.Data;
import com.soira.eri_scantron.view.SoiraButton;
import com.soira.eri_scantron.view.SoiraEditText;
import com.soira.eri_scantron.view.SoiraTextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import er.leafpedia.barka.CaptureActivity;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

import static com.face.ScanFace.isPredicting;
import static com.soira.eri_scantron.util.Fields.PASSWORD;
import static com.soira.eri_scantron.util.Fields.first;
import static com.soira.eri_scantron.util.Fields.intentional;


public class ExamSheet extends AppCompatActivity{

    OkHttpClient client;

    SharedPreferences sharedPreferences, shared;
    SharedPreferences.Editor editor;
    RelativeLayout wifi_warn, code_warn, waiting;
    SoiraEditText code_entry;
    SoiraButton start_code;
    SoiraTextView ver_a, ver_b;
    SoiraTextView ide, full_namee, gendere, rounde, numbere, streame, schoole;
    @Override
    protected void onResume() {
        super.onResume();
        isPredicting = false;
        intentional = false;
        first = true;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            if (!Settings.canDrawOverlays(this)){
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 5);
                return;
            }
        }
        ide.setText(":  " + sharedPreferences.getString("ID", "NOT SET"));
        full_namee.setText(":  " + sharedPreferences.getString("NAME", "NOT SET"));
        gendere.setText(":  " + sharedPreferences.getString("GENDER", "NOT SET"));
        rounde.setText(":  " + sharedPreferences.getString("ROUND", "NOT SET"));
        numbere.setText(":  " + sharedPreferences.getString("NUMBER", "NOT SET"));
        streame.setText(":  " + sharedPreferences.getString("STREAM", "NOT SET"));
        schoole.setText(":  " + sharedPreferences.getString("SCHOOL", "NOT SET"));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exam_sheet);
        OUTPUT = getFilesDir().getAbsolutePath() + "/images";

        init_views();
        init_listeners();

        closeWarning();
    }

    boolean code_warning = false, warning = false;
    private void init_listeners() {
        waiting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Nothing...
            }
        });
        start_code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = code_entry.getText().toString();
                if (code.isEmpty()){
                    code_entry.setError("Please enter code.");
                    return;
                }
                if (universal_code != null){
                    if (universal_code.equals(code)) {
                        String version = ver_a.isChecked() ? "A" : "B";
                        set_request("restart_exam:" + version + "#true");
                    }else {
                        code_entry.setError("Code is not correct.");
                    }
                }
            }
        });
    }

    private void init_views() {
        sharedPreferences = getSharedPreferences("ABEL", MODE_PRIVATE);
        shared = getSharedPreferences("DATA", MODE_PRIVATE);
        editor = shared.edit();
        wifi_warn = (RelativeLayout) findViewById(R.id.wifi_warn);
        code_warn = (RelativeLayout) findViewById(R.id.code_warn);
        waiting = (RelativeLayout) findViewById(R.id.wait);

        ver_a = (SoiraTextView) findViewById(R.id.ver_a);
        ver_a.setChecked(true);
        ver_b = (SoiraTextView) findViewById(R.id.ver_b);
        ver_b.setChecked(false);
        ide = (SoiraTextView) findViewById(R.id.idde_print);
        full_namee = (SoiraTextView) findViewById(R.id.usere_print);
        gendere = (SoiraTextView) findViewById(R.id.gendere_print);
        rounde = (SoiraTextView) findViewById(R.id.rounde_print);
        numbere = (SoiraTextView) findViewById(R.id.ide_print);
        streame = (SoiraTextView) findViewById(R.id.streame_print);
        schoole = (SoiraTextView) findViewById(R.id.schoole_print);

        code_entry = (SoiraEditText) findViewById(R.id.code_entry);
        start_code = (SoiraButton) findViewById(R.id.start_code);
    }

    private void init_data() throws Exception {
        String path = "/data/data/" + getPackageName() + "/exams";
        if (!new File(path).exists()){
            String a_path = "/data/data/" + getPackageName() + "/exams/version_a/";
            String b_path = "/data/data/" + getPackageName() + "/exams/version_b/";

            boolean a_created = new File(a_path).mkdirs();
            boolean b_created = new File(b_path).mkdirs();
            if (!a_created || !b_created){
                Toast.makeText(this, "Exam folder can\'t be created.", Toast.LENGTH_SHORT).show();
                return;
            }
            String[] a_lists = getAssets().list("version_a");
            for (String entry: a_lists) {
                InputStream inputStream = getAssets().open("version_a/" + entry);

                FileOutputStream output = new FileOutputStream(new File(a_path + entry));
                byte[] capacity = new byte[51200];
                Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(PASSWORD.getBytes(), "AES"), new IvParameterSpec(new byte[16]));
                OutputStream cipherOutput = new CipherOutputStream(output, cipher);
                while (true) {
                    int dolly = inputStream.read(capacity);
                    if (dolly == -1) break;
                    cipherOutput.write(capacity, 0, dolly);
                }
                cipherOutput.close();
                output.close();
                inputStream.close();
            }

            String[] b_lists = getAssets().list("version_b");
            for (String entry: b_lists) {
                InputStream inputStream = getAssets().open("version_b/" + entry);

                FileOutputStream fileOutputStream = new FileOutputStream(new File(b_path + entry));
                byte[] capacity = new byte[51200];
                Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec("0000211954721516".getBytes(), "AES"), new IvParameterSpec(new byte[16]));
                OutputStream outputStream = new CipherOutputStream(fileOutputStream, cipher);
                while (true) {
                    int dolly = inputStream.read(capacity);
                    if (dolly == -1) break;
                    outputStream.write(capacity, 0, dolly);
                }
                outputStream.close();
                fileOutputStream.close();
                inputStream.close();
            }
        }
    }



    boolean halted = false;
    @Override
    public void onBackPressed(){
        if (waiting.getVisibility() == View.VISIBLE){
            return;
        }
        if (warning){
            closeWarning();
            return;
        }
        if (code_warning){
            closeCodeWarn();
            return;
        }
        if (assurance_opened){
            deprint_information();
            return;
        }

        halted = true;
        if (call != null){
            call.cancel();
            call = null;
        }
        Intent intent = new Intent(ExamSheet.this, DownloadDB.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("exit", true);
        startActivity(intent);
        super.onBackPressed();

    }


    boolean assurance_opened = false;
    boolean onProcess = false;
    public void start(View view) {
        if (onProcess){
            return;
        }
        String answers = shared.getString("ANSWERS", null);
        if (answers != null){
            Toast.makeText(this, "Sending answers from last session.", Toast.LENGTH_SHORT).show();
            set_request("finish_exam:" + answers);
            return;
        }

        if (!sharedPreferences.getBoolean("REG", false)){
            Toast.makeText(this, "You must register to start exam.", Toast.LENGTH_SHORT).show();
            edit(null);
            return;
        }

        start_now(null);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK){
            String resulted_values = data.getStringExtra(CaptureActivity.EXTRA_RESULT);
            if (resulted_values != null){
                String[] then = resulted_values.split(",");
                if (then.length == 2){
                    if (then[0].equals("abel_nebay") && then[1].startsWith("PAX777SUBJECT")){
                        open_exam(resulted_values);
                        return;
                    }
                }
            }
            Toast.makeText(this, "Exam is not available for this subject.", Toast.LENGTH_SHORT).show();
        }
        if (requestCode == 500 && resultCode == RESULT_OK){
            String exam = START_EXAM;
            information_before_start =
                    sharedPreferences.getString("ID", "NOT SET") + ":" +
                            sharedPreferences.getString("NAME", "NOT SET") + ":" +
                            sharedPreferences.getString("SCHOOL", "NOT SET") + ":" +
                            sharedPreferences.getString("NUMBER", "NOT SET") + ":" +
                            sharedPreferences.getString("ROUND", "NOT SET") + ":" +
                            sharedPreferences.getString("GENDER", "NOT SET") + ":" +
                            sharedPreferences.getString("STREAM", "NOT SET");

            String subject = exam.split(",")[0];
            String version = exam.split(",")[1];
            String timeout = exam.split(",")[2];
            String form = exam.split(",")[3];
            String report = exam.split(",")[4];

            startActivity(new Intent(ExamSheet.this, OpenExam.class)
                    .putExtra("subject", subject)
                    .putExtra("version", version)
                    .putExtra("timeout", timeout)
                    .putExtra("form", form)
                    .putExtra("report", report)
                    .putExtra("information", information_before_start));
        }

    }

    String subject_to_start = null, information_before_start = null;
    private void open_exam(String resulted_values) {
//        information_before_start = resulted_values.split(",")[0];
        information_before_start =
                sharedPreferences.getString("ID", "NOT SET") + ":" +
                sharedPreferences.getString("NAME", "NOT SET") + ":" +
                sharedPreferences.getString("SCHOOL", "NOT SET") + ":" +
                sharedPreferences.getString("NUMBER", "NOT SET") + ":" +
                sharedPreferences.getString("ROUND", "NOT SET") + ":" +
                sharedPreferences.getString("GENDER", "NOT SET") + ":" +
                sharedPreferences.getString("STREAM", "NOT SET");

        subject_to_start = resulted_values.split(",")[1].substring(13);

        print_data_first(information_before_start);

    }

    private void print_data_first(String resulted_values) {
        String[] contents = resulted_values.split(":");
        assurance_opened = true;
        String id_val = contents[0];
        String name_val = contents[1];
        String school_val = contents[2];
        String number_val = contents[3];
        String round_val = contents[4];
        String gender_val = contents[5];
        String stream_val = contents[6];


    }

    private void deprint_information(){
        assurance_opened = false;
    }

    public void nothing(View view) {
        // nothing...
    }

    boolean waiting_halted = false;
    Runnable waiting_runner = new Runnable() {
        @Override
        public void run() {
            if (!waiting_halted) {
                waiting.setVisibility(View.VISIBLE);
            }
        }
    };
    Handler waiting_handler;
    Call call;
    private void set_request(String post) {
        waiting_halted = false;
        onProcess = true;
        if (waiting_handler != null){
            waiting_handler.removeCallbacks(waiting_runner);
            waiting_handler = null;
        }
        waiting_handler = new Handler();
        waiting_handler.postDelayed(waiting_runner, 1000);
        if (client != null) {
            client = null;
        }
        client = new OkHttpClient();

        FormBody formBody = new FormBody.Builder().add(post.split(":")[0], post.split(":")[1]).build();
        Request request = new Request.Builder().url(Data.GENERAL_URL).post(formBody).build();
        if (call != null){
            call.cancel();
            call = null;
        }
        call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, final IOException e) {
                waiting_halted = true;
                if (waiting_handler != null){
                    waiting_handler.removeCallbacks(waiting_runner);
                    waiting_handler = null;
                }
                call.cancel();
                ExamSheet.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        waiting.setVisibility(View.GONE);
                        error_message();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (halted)return;
                waiting_halted = true;
                ResponseBody resp = response.body();
                if (resp != null) {
                    String body = resp.string();
                    if (body != null && body.equals("null_0")){
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(ExamSheet.this, "Exam is not started yet. Try again soon.", Toast.LENGTH_SHORT).show();
                            }
                        });
                        return;
                    }
                    if (body == null || body.length() == 0 || body.split(":").length != 2){
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                error_message();
                            }
                        });
                        return;
                    }
                    String key = body.split(":")[0];
                    final String value = body.split(":")[1]; // ENGLISH,A,60,5#4#4

                    switch (key) {
                        case "start_exam":
                            ExamSheet.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    waiting.setVisibility(View.GONE);
                                    if (value.equals("null")){
                                        error_message();
                                        return;
                                    }
                                    strip_exams(value);
                                }
                            });
                            break;
                        case "finish_exam":
                            ExamSheet.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (value.equals("thank_you")) {
                                        editor.putString("ANSWERS", null).apply();
                                        Toast.makeText(ExamSheet.this, "Exam successfully added to the database.", Toast.LENGTH_SHORT).show();
                                    }else {
                                        Toast.makeText(ExamSheet.this, "Try again.", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                            break;
                    }
                }
                onProcess = false;
            }
        });
    }

    String START_EXAM = null;
    private void strip_exams(String exam) {
        START_EXAM = exam;
        if (exam.startsWith("null")){
            universal_code = exam.split(",")[1];
            openCodeWarn();
            return;
        }
        File file = new File(OUTPUT);
        if (!file.exists() || file.listFiles().length == 0){
            waiting.setVisibility(View.VISIBLE);
            download_images(1);
            return;
        }

        // ENGLISH,A,60,5#4#4 || null,0021
        Intent intent = new Intent(ExamSheet.this, ScanFace.class);
        startActivityForResult(intent, 500);
    }

    String OUTPUT = null;
    private void download_images(final int index) {
        String id_val = sharedPreferences.getString("ID", "NOT SET");

        String download_dir = Data.IMAGE_URL+"/"+String.valueOf(id_val)+"/pic"+String.valueOf(index)+".jpeg";
        int downloadId = PRDownloader.download(download_dir, OUTPUT, "pic"+String.valueOf(index)+".jpeg")
                .build()
                .setOnPauseListener(new OnPauseListener() {
                    @Override
                    public void onPause() {
//                        error_message();
                    }
                })
                .setOnCancelListener(new OnCancelListener() {
                    @Override
                    public void onCancel() {
                        update_download(index);
//                        error_message();
                    }
                })
                .start(new OnDownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        update_download(index);
                    }

                    @Override
                    public void onError(Error error) {
                        //error_message();
                        update_download(index);

                    }
                });
    }

    private void update_download(int index) {
        int i = index+1;
        if (i > 30){
            try {
                FaceRegister faceRegister = new FaceRegister();
                faceRegister.trainModels(this);
            }catch (Exception e){
                waiting.setVisibility(View.GONE);
                Toast.makeText(this, "No images found. Try to free more spaces & try again.", Toast.LENGTH_LONG).show();
                return;
            }
            waiting.setVisibility(View.GONE);
            // ENGLISH,A,60,5#4#4 || null,0021
            Intent intent = new Intent(ExamSheet.this, ScanFace.class);
            startActivityForResult(intent, 500);
            return;
        }
        download_images(i);
    }

    String universal_code = null;
    private void openCodeWarn() {
        code_warning = true;
        code_warn.setVisibility(View.VISIBLE);
        if (code_entry.isFocusable()){
            code_entry.requestFocus();
            SoftKeypax.openSoft(ExamSheet.this, code_entry);
            code_entry.setText("");
        }
    }

    private void closeCodeWarn() {
        SoftKeypax.hideSoft(this, R.id.exam_layout, null);
        code_warning = false;
        code_entry.setError(null);
        code_entry.setText("");
        code_warn.setVisibility(View.GONE);
    }

    private void error_message() {
        warning = true;
        openWarning("CONNECTION FAILED.\nPLEASE RESTART THE APP.");
    }

    private void openWarning(String message){
        wifi_warn.setVisibility(View.VISIBLE);
    }

    private void closeWarning(){
        warning = false;
        wifi_warn.setVisibility(View.GONE);
    }

    public void start_now(View view) {
        String device_id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        if (device_id == null){
            device_id = "free";
        }
        device_id = device_id.replaceAll(":","_");
        device_id = device_id.replaceAll(",","_");
        device_id = device_id.replaceAll("#","_");

        String model = Build.MODEL;
        String manufacture = Build.MANUFACTURER;
        String caps = "";
        if (model != null){
            caps += model;
        }
        if (manufacture != null){
            caps += manufacture;
        }
        caps = caps.replaceAll(":","_");
        caps = caps.replaceAll(",","_");
        caps = caps.replaceAll("#","_");
        String version = ver_a.isChecked() ? "A" : "B";

        set_request("start_exam:" + version + "#" + device_id+caps);
    }

    public void try_again(View view) {
        deprint_information();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        deprint_information();
    }

    public void edit(View view) {
        if (onProcess)return;
        startActivity(new Intent(ExamSheet.this, AddStudent.class));
    }

    public void retry(View view) {
        closeWarning();
        String device_id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        if (device_id == null){
            device_id = "free";
        }
        device_id = device_id.replaceAll(":","_");
        device_id = device_id.replaceAll(",","_");
        device_id = device_id.replaceAll("#","_");

        String model = Build.MODEL;
        String manufacture = Build.MANUFACTURER;
        String caps = "";
        if (model != null){
            caps += model;
        }
        if (manufacture != null){
            caps += manufacture;
        }
        caps = caps.replaceAll(":","_");
        caps = caps.replaceAll(",","_");
        caps = caps.replaceAll("#","_");
        String version = ver_a.isChecked() ? "A" : "B";

        set_request("start_exam:" + version + "#" + device_id+caps);
    }

    public void version_clicked(View view) {
        if (view.getId() == R.id.ver_a){
            ver_a.setChecked(true);
            ver_b.setChecked(false);
        }else{
            ver_b.setChecked(true);
            ver_a.setChecked(false);

        }
    }
}
