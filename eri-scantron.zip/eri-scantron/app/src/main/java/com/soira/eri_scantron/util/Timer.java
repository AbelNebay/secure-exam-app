package com.soira.eri_scantron.util;


public class Timer {

    public static String timing(double total) {
        double durationS = total / 1000.0d;
        int durationSS = (int) Math.floor(durationS % 60.0d);
        int durationMM = (int) Math.floor((durationS / 60.0d) % 60.0d);
        int durationHH = (int) Math.floor((durationS / 3600.0d) % 60.0d);
        if (durationHH == 0.0d) {
            return (durationMM < 10 ? "0" + String.valueOf(durationMM).substring(0, 1) : String.valueOf(durationMM)) + ":" + (durationSS < 10 ? "0" + String.valueOf(durationSS).substring(0, 1) : String.valueOf(durationSS));
        } else {
            return (durationHH < 10 ? String.valueOf(durationHH).substring(0, 1) : String.valueOf(durationHH)) + ":" + (durationMM < 10 ? "0" + String.valueOf(durationMM).substring(0, 1) : String.valueOf(durationMM)) + ":" + (durationSS < 10 ? "0" + String.valueOf(durationSS).substring(0, 1) : String.valueOf(durationSS));
        }
    }
}
