package com.soira.eri_scantron.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.soira.eri_scantron.R;
import com.soira.eri_scantron.interfaces.OnConditionMet;
import com.soira.eri_scantron.view.SoiraTextView;

import java.util.ArrayList;


public class AddStudentRecyclerAdapter extends RecyclerView.Adapter<AddStudentRecyclerAdapter.ViewHolder> {

    private ArrayList<String> media_stored;

    private OnConditionMet onConditionMet;

    private void fire_condition(String values){
        if (onConditionMet == null){
            return;
        }
        onConditionMet.onConditionMet(values);
    }

    private Context context;

    public AddStudentRecyclerAdapter(Context context, ArrayList<String> media_stored, OnConditionMet onConditionMet) {
        this.context = context;
        this.media_stored = media_stored;
        this.onConditionMet = onConditionMet;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout database_holder;
        SoiraTextView student_name, student_school;

        ViewHolder(@NonNull View v) {
            super(v);


            database_holder = (RelativeLayout) v.findViewById(R.id.database_holder);
            student_name = (SoiraTextView) v.findViewById(R.id.student_name);
            student_school = (SoiraTextView) v.findViewById(R.id.student_school);

        }
        void setData(@NonNull final ArrayList<String> medias, final int position){
            final String values = medias.get(position);

            String name = values.split(":")[1];
            String school = values.split(":")[0] + " -> " + values.split(":")[2];

            student_name.setText(name);
            student_school.setText(school);

            database_holder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fire_condition(values);
                }
            });
        }
    }

    @NonNull
    @Override
    public AddStudentRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.add_student_media_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.setData(media_stored, position);
    }

    @Override
    public void onViewAttachedToWindow(ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
    }

    @Override
    public int getItemCount() {
        return media_stored.size();
    }

}