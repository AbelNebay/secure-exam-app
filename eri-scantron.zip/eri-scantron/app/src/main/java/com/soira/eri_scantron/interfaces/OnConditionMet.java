package com.soira.eri_scantron.interfaces;


public interface OnConditionMet {

    void onConditionMet(int id);

    void onConditionMet(String id);

}
