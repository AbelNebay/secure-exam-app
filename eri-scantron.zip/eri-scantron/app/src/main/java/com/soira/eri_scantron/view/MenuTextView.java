package com.soira.eri_scantron.view;


import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

public class MenuTextView extends TextView{

    private void establishFont(){
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "menu_font.ttf"));
    }

    public MenuTextView(Context context) {
        super(context);
        establishFont();
    }

    public MenuTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        establishFont();
    }

    public MenuTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        establishFont();
    }

}
