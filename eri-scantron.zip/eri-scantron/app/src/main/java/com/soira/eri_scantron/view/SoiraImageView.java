package com.soira.eri_scantron.view;


import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

public class SoiraImageView extends ImageView {

    public SoiraImageView(Context context) {
        super(context);
        
    }

    public SoiraImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        
    }

    public SoiraImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        
    }

}
