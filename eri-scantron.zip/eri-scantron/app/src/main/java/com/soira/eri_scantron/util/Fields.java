package com.soira.eri_scantron.util;


import java.util.ArrayList;

public class Fields {

    public static final String PASSWORD = "0000135792468016";

    public static final String ENGLISH = "ENGLISH";
    public static final String MATHEMATICS = "MATHEMATICS";
    public static final String BIOLOGY = "BIOLOGY";
    public static final String CHEMISTRY = "CHEMISTRY";
    public static final String PHYSICS = "PHYSICS";

    public static boolean intentional = false;
    public static boolean first = true, locked = false;

    public static long official_time = /*(3*3600000)*/ 45 * 60 * 1000, time_started = 0L;

    public static ArrayList<String> selected;
    public static String[] selected_answers;
}
