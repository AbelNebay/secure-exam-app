package com.soira.eri_scantron;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Switch;

import com.downloader.Error;
import com.downloader.OnCancelListener;
import com.downloader.OnDownloadListener;
import com.downloader.OnPauseListener;
import com.downloader.PRDownloader;
import com.face.utils.FaceRegister;
import com.soira.eri_scantron.adapter.AddStudentRecyclerAdapter;
import com.soira.eri_scantron.database.StudentsDatabase;
import com.soira.eri_scantron.interfaces.OnConditionMet;
import com.soira.eri_scantron.keyboard.SoftKeypax;
import com.soira.eri_scantron.util.Data;
import com.soira.eri_scantron.view.SoiraAutoCompleteTextView;
import com.soira.eri_scantron.view.SoiraButton;
import com.soira.eri_scantron.view.SoiraTextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class AddStudent extends AppCompatActivity {
    RecyclerView stored_lister;
    SoiraAutoCompleteTextView search_stored;
    SoiraTextView warning_text;

    RelativeLayout waiting;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    SoiraTextView
            id_text, id,
            full_name_text, full_name,
            gender_text, gender,
            round_text, round,
            number_text, number,
            stream_text, stream,
            school_text, school;

    RelativeLayout outer_alert, inner_alert, bottomers;
    ScrollView media_info_panel;
    SoiraButton register_button, finish_button;
    ImageView clear_text;
    boolean opened = false, message_opened = false;

    @Nullable
    ArrayList<String> stored_students = new ArrayList<>();

    private void fetch_ournic(){
        if (stored_students.size() > 0){
            stored_students.clear();
        }
        Cursor cursor = new StudentsDatabase(this).getAllData();
        if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()){
            do {
                String id = cursor.getString(cursor.getColumnIndex(StudentsDatabase.ID));
                String full_name = cursor.getString(cursor.getColumnIndex(StudentsDatabase.FULL_NAME));
                String school = cursor.getString(cursor.getColumnIndex(StudentsDatabase.SCHOOL));
                String number = cursor.getString(cursor.getColumnIndex(StudentsDatabase.NUMBER));
                String round = cursor.getString(cursor.getColumnIndex(StudentsDatabase.ROUND));
                String gender = cursor.getString(cursor.getColumnIndex(StudentsDatabase.GENDER));
                String stream = cursor.getString(cursor.getColumnIndex(StudentsDatabase.STREAM));

                String combined = id + ":" + full_name + ":" + school + ":" + number + ":" + round + ":" + gender + ":" + stream;

                stored_students.add(combined);
            }while (cursor.moveToNext());
            cursor.close();
        }
        if (stored_students.size() == 0){
            search_stored.setEnabled(false);
            warning_text.setText("No student data.");
            warning_text.setVisibility(View.VISIBLE);
            if (stored_lister != null) {
                stored_lister.setAdapter(null);
            }
        }else {
            search_stored.setEnabled(true);
            warning_text.setVisibility(View.GONE);
            warning_text.setText("");
            set_whole();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_student_layout);
        OUTPUT = getFilesDir().getAbsolutePath() + "/images";

        init_views();
        sharedPreferences = getSharedPreferences("ABEL", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        init_listeners();
        fetch_ournic();

    }

    private void setClosed(){
        waiting.setVisibility(View.GONE);
        inner_alert.animate().alpha(0f).setDuration(80).withEndAction(new Runnable() {
            @Override
            public void run() {
                deprint_information();
                outer_alert.setVisibility(View.GONE);
                opened = false;
                message_opened = false;
                if (search_stored.isFocusable()){
                    search_stored.requestFocus();
                    SoftKeypax.openSoft(AddStudent.this, search_stored);
                    search_stored.setText("");
                }
            }
        });
        bottomers.animate().alpha(0f).setDuration(80).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.GONE);
            }
        });
    }



    private void setOpened(@NonNull String code_value){
        print_information(code_value);
        inner_alert.setAlpha(0f);
        bottomers.setAlpha(0f);

        SoftKeypax.hideSoft(this, R.id.add_student_layout, null);

        outer_alert.setVisibility(View.VISIBLE);

        bottomers.animate().alpha(1f).setDuration(80).withEndAction(new Runnable() {
            @Override
            public void run() {
                bottomers.setVisibility(View.VISIBLE);
            }
        });

        inner_alert.animate().alpha(1f).setDuration(80).withEndAction(new Runnable() {
            @Override
            public void run() {
                opened = true;
                message_opened = false;
            }
        });
    }


    private void deprint_information(){
        media_info_panel.setVisibility(View.GONE);

        id.setText("");
        full_name.setText("");
        school.setText("");
        number.setText("");
        round.setText("");
        gender.setText("");
        stream.setText("");
    }

    String id_val, name_val, school_val, number_val, round_val, gender_val, stream_val;
    private void print_information(@NonNull String received) {
        media_info_panel.setVisibility(View.VISIBLE);
        String[] media_content = received.split(":");

        id_val = media_content[0];
        name_val = media_content[1];
        school_val = media_content[2];
        number_val = media_content[3];
        round_val = media_content[4];
        gender_val = media_content[5];
        stream_val = media_content[6];


        id.setText(" :  " + id_val);
        full_name.setText(" :  " + name_val);
        school.setText(" :  " + school_val);

        number.setText(" :  " + number_val);

        round.setText(" :  " + round_val);
        gender.setText(" :  " + gender_val);
        stream.setText(" :  " + stream_val);

    }

    private void init_views() {
        waiting = (RelativeLayout) findViewById(R.id.wait);

        stored_lister = (RecyclerView) findViewById(R.id.stored_medias);
        search_stored = (SoiraAutoCompleteTextView) findViewById(R.id.change_name);
        outer_alert = (RelativeLayout) findViewById(R.id.outer_alert);
        media_info_panel = (ScrollView) findViewById(R.id.media_info_panel);
        bottomers = (RelativeLayout) findViewById(R.id.bottomers);

        inner_alert = (RelativeLayout) findViewById(R.id.inner_alert);
        finish_button = (SoiraButton) findViewById(R.id.finish_button);
        register_button = (SoiraButton) findViewById(R.id.register_button);
        warning_text = (SoiraTextView) findViewById(R.id.warning);

        id = (SoiraTextView) findViewById(R.id.id);
        id_text = (SoiraTextView) findViewById(R.id.id_text);

        full_name = (SoiraTextView) findViewById(R.id.full_name);
        full_name_text = (SoiraTextView) findViewById(R.id.full_name_text);

        gender = (SoiraTextView) findViewById(R.id.gender);
        gender_text = (SoiraTextView) findViewById(R.id.gender_text);

        round = (SoiraTextView) findViewById(R.id.round);
        round_text = (SoiraTextView) findViewById(R.id.round_text);

        number = (SoiraTextView) findViewById(R.id.number);
        number_text = (SoiraTextView) findViewById(R.id.number_text);

        stream = (SoiraTextView) findViewById(R.id.stream);
        stream_text = (SoiraTextView) findViewById(R.id.stream_text);

        school = (SoiraTextView) findViewById(R.id.school);
        school_text = (SoiraTextView) findViewById(R.id.school_text);

        clear_text = (ImageView) findViewById(R.id.store_clear_text);
    }

    private void apply_clearing() {
        if (search_stored.getText().length() > 0){
            clear_text.setVisibility(View.VISIBLE);
        }else {
            clear_text.setVisibility(View.GONE);
        }
    }

    private void init_listeners() {
        waiting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Nothing...
            }
        });
        apply_clearing();
        clear_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search_stored.setText("");
                clear_text.setVisibility(View.GONE);
            }
        });
        search_stored.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                apply_clearing();
                if (stored_students.size() == 0){
                    return;
                }
                String entered = search_stored.getText().toString();
                if (entered != null && entered.length() > 0){
                    ArrayList<String> found = new ArrayList<>();
                    for (int i = 0; i < stored_students.size(); i++){
                        String current = stored_students.get(i);
                        if (current.toLowerCase().contains(entered.toLowerCase())){
                            found.add(current);
                        }
                    }
                    if (found.size() == 0){
                        warning_text.setText("No student matches your search.");
                        warning_text.setVisibility(View.VISIBLE);
                        set_stored_lists(null);
                    }else {
                        warning_text.setVisibility(View.GONE);
                        warning_text.setText("");
                        set_stored_lists(found);
                    }
                }else {
                    set_whole();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        outer_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // A thing wasn't done here.
            }
        });

        inner_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // We did nothing...
            }
        });

        finish_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setClosed();
            }
        });

        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                waiting.setVisibility(View.VISIBLE);
                File file = new File(OUTPUT);
                if (file.exists()){
                    for (File entry: file.listFiles()){
                        entry.delete();
                    }
                }
                download_images(1);
            }
        });
    }
    String OUTPUT = null;
    private void download_images(final int index) {
        String download_dir = Data.IMAGE_URL+"/"+String.valueOf(id_val)+"/pic"+String.valueOf(index)+".jpeg";
        int downloadId = PRDownloader.download(download_dir, OUTPUT, "pic"+String.valueOf(index)+".jpeg")
                .build()
                .setOnPauseListener(new OnPauseListener() {
                    @Override
                    public void onPause() {
//                        error_message();
                    }
                })
                .setOnCancelListener(new OnCancelListener() {
                    @Override
                    public void onCancel() {
                        update_download(index);
//                        error_message();
                    }
                })
                .start(new OnDownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        update_download(index);
                    }

                    @Override
                    public void onError(Error error) {
                        //error_message();
                        update_download(index);

                    }
                });
    }

    private void update_download(int index) {
        int i = index+1;
        if (i > 30){
            try {
                FaceRegister faceRegister = new FaceRegister();
                faceRegister.trainModels(this);
            }catch (Exception ignored){}
            editor.putBoolean("REG", true).apply();

            editor.putString("ID", id_val).apply();
            editor.putString("NAME", name_val).apply();
            editor.putString("GENDER", gender_val).apply();
            editor.putString("ROUND", round_val).apply();
            editor.putString("NUMBER", number_val).apply();
            editor.putString("STREAM", stream_val).apply();
            editor.putString("SCHOOL", school_val).apply();

            setClosed();
            finish();
            return;
        }
        download_images(i);
    }

    private void set_whole() {
        warning_text.setVisibility(View.GONE);
        warning_text.setText("");
        ArrayList<String> secondary = new ArrayList<>();
        for (String entry: stored_students){
            secondary.add(entry);
        }
        set_stored_lists(secondary);
    }

    @Nullable
    AddStudentRecyclerAdapter addStudentRecyclerAdapter;
    private void set_stored_lists(@Nullable ArrayList<String> entered) {
        if (entered == null || entered.size() == 0){
            if (stored_lister != null) {
                stored_lister.setAdapter(null);
            }
            return;
        }

        stored_lister.setLayoutManager(new LinearLayoutManager(this));
        addStudentRecyclerAdapter = new AddStudentRecyclerAdapter(AddStudent.this, entered, new OnConditionMet() {
            @Override
            public void onConditionMet(int id) {

            }

            @Override
            public void onConditionMet(@NonNull String values) {
                setOpened(values);
            }
        });
        stored_lister.setAdapter(addStudentRecyclerAdapter);
    }
    
    @Override
    public void onBackPressed() {
        if (opened){
            setClosed();
            return;
        }
        if (!sharedPreferences.getBoolean("REG", false)) {
            Intent intent = new Intent(AddStudent.this, Intro.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("exit", true);
            startActivity(intent);
            return;
        }
        super.onBackPressed();
    }

    public void back_home_history(View view) {
        onBackPressed();
    }

    public void clear(View view) {

    }

    public void nombre(View view) {
        Switch switch_button = (Switch)view;
        if (switch_button.isChecked()){
            search_stored.setInputType(InputType.TYPE_CLASS_TEXT);
        }else {
            search_stored.setInputType(InputType.TYPE_CLASS_NUMBER);
        }
    }
}
