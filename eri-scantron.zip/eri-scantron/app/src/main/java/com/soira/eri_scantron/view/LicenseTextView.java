package com.soira.eri_scantron.view;


import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

public class LicenseTextView extends TextView{

    private void establishFont(){
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "geez.ttf"));
    }

    public LicenseTextView(Context context) {
        super(context);
        establishFont();
    }

    public LicenseTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        establishFont();
    }

    public LicenseTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        establishFont();
    }

}
