package com.soira.eri_scantron.view;


import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

import com.soira.eri_scantron.R;

public class SoiraTextView extends TextView{

    boolean checked = false;

    public void setChecked(boolean condition){
        checked = condition;
        if (condition){
            setBackgroundResource(R.drawable.choice_button_selected);
            setTextColor(Color.parseColor("#FFFFFF"));
        }else {
            setBackgroundResource(R.drawable.choice_button);
            setTextColor(Color.parseColor("#000000"));
        }
    }

    public boolean isChecked(){
        return checked;
    }

    private void establishFont(){
        if (getTag() != null){
            boolean what = getTag().equals("vip");
            if (what){
                setTypeface(Typeface.createFromAsset(getContext().getAssets(), "vip.ttf"));
                return;
            }
        }
        setTypeface(Typeface.createFromAsset(getContext().getAssets(), "soira_font.ttf"));
    }
    
    public SoiraTextView(Context context) {
        super(context);
        establishFont();
        
    }

    public SoiraTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        establishFont();
        
    }

    public SoiraTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        establishFont();
        
    }

}
