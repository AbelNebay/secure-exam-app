package com.face;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.SurfaceView;
import android.widget.Toast;

import com.face.utils.StorageHelper;
import com.google.zxing.common.reedsolomon.a;
import com.soira.eri_scantron.R;

import org.bytedeco.javacpp.opencv_core;

import static org.bytedeco.javacpp.opencv_core.LINE_8;
import static org.bytedeco.javacpp.opencv_imgproc.CV_BGR2GRAY;
import static org.bytedeco.javacpp.opencv_imgproc.cvtColor;
import static org.bytedeco.javacpp.opencv_imgproc.rectangle;

public class ScanFace extends AbstractCameraPreviewActivity {

    public static boolean isPredicting = false;
    @Override
    public opencv_core.Mat onCameraFrame(opencv_core.Mat rgbaMat) {
        if (faceDetector != null) {
            opencv_core.Mat grayMat = new opencv_core.Mat(rgbaMat.rows(), rgbaMat.cols());
            cvtColor(rgbaMat, grayMat, CV_BGR2GRAY);
            opencv_core.RectVector faces = new opencv_core.RectVector();
            faceDetector.detectMultiScale(grayMat, faces, 1.1, 2, 2,
                    new opencv_core.Size(absoluteFaceSize, absoluteFaceSize),
                    new opencv_core.Size(4 * absoluteFaceSize, 4 * absoluteFaceSize));
            opencv_core.Mat duplicateMat = rgbaMat.clone();
            opencv_core.Mat croppedMat = null;
            if (faces.size() == 1) {
                int x = faces.get(0).x();
                int y = faces.get(0).y();
                int w = faces.get(0).width();
                int h = faces.get(0).height();
                rectangle(rgbaMat, new opencv_core.Point(x, y), new opencv_core.Point(x + w, y + h), opencv_core.Scalar.GREEN, 2, LINE_8, 0);
                croppedMat = new opencv_core.Mat(duplicateMat, faces.get(0));
            }
            try {
                isPredicting = true;
                boolean recognizedFace = faceRegister.predict(this, croppedMat!=null?croppedMat:duplicateMat);
                if(recognizedFace) {
                    faceDetector.setNull();
                    faceDetector = null;
                    this.runOnUiThread(new Runnable() {
                        public void run() {
                            isPredicting = true;
                            Intent resultData = new Intent();
                            setResult(RESULT_OK, resultData);
                            finish();
                        }
                    });
                }
            }catch (Exception e){
                this.runOnUiThread(new Runnable() {
                  @Override
                  public void run() {
                      finish();
                  }
              });
            } finally {
                isPredicting = false;
                duplicateMat.release();
            }
            grayMat.release();
        }
        return rgbaMat;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        finish();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scan_face);

        cameraView = (CvCameraPreview) findViewById(R.id.camera_view);
        cameraView.setVisibility(SurfaceView.VISIBLE);
        cameraView.setCvCameraViewListener(this);

        turbo = new Turbo();
        turbo.execute();
    }

    Turbo turbo;
    class Turbo extends AsyncTask<Void, Void, Void>{

        @Override
        protected Void doInBackground(Void... voids) {
            faceDetector = StorageHelper.loadClassifierCascade(ScanFace.this, R.raw.frontalface);
            return null;
        }
    }

}
