package com.face.utils;

import android.content.Context;

import org.bytedeco.javacpp.opencv_core.Mat;
import org.bytedeco.javacpp.opencv_objdetect.CascadeClassifier;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import static org.bytedeco.javacpp.opencv_imgcodecs.imwrite;
import static org.bytedeco.javacpp.opencv_imgproc.COLOR_RGB2BGR;
import static org.bytedeco.javacpp.opencv_imgproc.cvtColor;


public class StorageHelper {
  final static String TAG = "StorageHelper";

  public static CascadeClassifier loadClassifierCascade(Context context, int resId) {
    FileOutputStream fos = null;
    InputStream inputStream;

    inputStream = context.getResources().openRawResource(resId);
    File xmlDir = context.getDir("xml", Context.MODE_PRIVATE);
    File cascadeFile = new File(xmlDir, "temp.xml");
    try {
      fos = new FileOutputStream(cascadeFile);
      byte[] buffer = new byte[4096];
      int bytesRead;
      while ((bytesRead = inputStream.read(buffer)) != -1) {
        fos.write(buffer, 0, bytesRead);
      }
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
      if (fos != null) {
        try {
          fos.close();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }

    CascadeClassifier detector = new CascadeClassifier(cascadeFile.getAbsolutePath());
    if (detector.isNull()) {
      detector = null;
    }
    boolean deleted = cascadeFile.delete();
    return detector;
  }

  public static File loadXmlFromRes2File(Context context, int resId, String filename) {
    FileOutputStream fos = null;
    InputStream inputStream;

    inputStream = context.getResources().openRawResource(resId);
    File trainDir = context.getDir("xml", Context.MODE_PRIVATE);
    File trainFile = new File(trainDir, filename);
    try {
      fos = new FileOutputStream(trainFile);
      byte[] buffer = new byte[4096];
      int bytesRead;
      while ((bytesRead = inputStream.read(buffer)) != -1) {
        fos.write(buffer, 0, bytesRead);
      }
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      if (inputStream != null) {
        try {
          inputStream.close();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
      if (fos != null) {
        try {
          fos.close();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }

    return trainFile;
  }

  public static File saveMat2File(Mat mat, String filePath, String fileName) {
    File path = new File(filePath);
    if (!path.exists()) {
      path.mkdir();
    }
    File file = new File(path, fileName);
    Mat mat2Save = new Mat();
    cvtColor(mat, mat2Save, COLOR_RGB2BGR);
    boolean result = imwrite(file.toString(), mat2Save);
    mat2Save.release();
    if (result)
      return file;
    else
      return null;
  }
}
