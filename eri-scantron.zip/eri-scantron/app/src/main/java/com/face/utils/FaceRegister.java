package com.face.utils;


import android.content.Context;

import org.bytedeco.javacpp.DoublePointer;
import org.bytedeco.javacpp.IntPointer;
import org.bytedeco.javacpp.opencv_core;
import org.bytedeco.javacpp.opencv_face.FaceRecognizer;
import org.bytedeco.javacpp.opencv_face.LBPHFaceRecognizer;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.IntBuffer;

import static org.bytedeco.javacpp.opencv_imgcodecs.CV_LOAD_IMAGE_GRAYSCALE;
import static org.bytedeco.javacpp.opencv_imgcodecs.imread;
import static org.bytedeco.javacpp.opencv_imgcodecs.imwrite;
import static org.bytedeco.javacpp.opencv_imgproc.resize;

public class FaceRegister{

    private FaceRecognizer faceRecognizer;
    public void trainModels(Context context) throws IOException{
        String OUTPUT = context.getFilesDir().getAbsolutePath() + "/images";
        FilenameFilter fileNameFilter = new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return /*name.toLowerCase().endsWith(".jpg")||*/name.toLowerCase().endsWith(".jpeg");

            }
        };
        File path = new File(OUTPUT);//context.getFilesDir();
        File[] capturedImages = path.listFiles(fileNameFilter);
        opencv_core.Mat labels = new opencv_core.Mat(capturedImages.length, 1, opencv_core.CV_32SC1);
        opencv_core.MatVector images = new opencv_core.MatVector(capturedImages.length);
        opencv_core.Mat mats[] = new opencv_core.Mat[capturedImages.length];
        IntBuffer labelsBuf = labels.createBuffer();
        for (int i = 0; i < capturedImages.length; i++){
            File imageFile = capturedImages[i];
            opencv_core.Mat img = imread(imageFile.getAbsolutePath(), CV_LOAD_IMAGE_GRAYSCALE);
            if(img == null){
                throw new IOException("Unable to load CV IMage from path: "+imageFile.getAbsolutePath());
            }

            labelsBuf.put(i, 1);
            images.put(i, img);
            mats[i] = img;
        }
        File databaseModelFile = new File(OUTPUT, "train.xml");
        FaceRecognizer faceRecognizer = LBPHFaceRecognizer.create(2,8,8,8,200);
        faceRecognizer.train(images,labels);

        faceRecognizer.save(databaseModelFile.getAbsolutePath());
        for(opencv_core.Mat mat:mats) mat.release();
    }


    private long lastPredictTime;
    public boolean predict(Context context, opencv_core.Mat mat) throws IOException{
        if (mat == null)return false;
        String OUTPUT = context.getFilesDir().getAbsolutePath() + "/images";
        long lastClickTime = lastPredictTime;
        long now = System.currentTimeMillis();
        if (now - lastClickTime < 500) {
              return false;
         }
        lastPredictTime = now;

        File path = new File(OUTPUT);//context.getFilesDir();
        File file = new File(path, "current.jpg");

        opencv_core.Mat resizedImage = new opencv_core.Mat();
        opencv_core.Size size = new opencv_core.Size(200, 200);
        resize(mat, resizedImage, size);
        imwrite(file.getAbsolutePath(), resizedImage);

        opencv_core.Mat image = imread(file.getAbsolutePath(), CV_LOAD_IMAGE_GRAYSCALE);

        IntPointer label = new IntPointer(1);
        DoublePointer confidence = new DoublePointer(1);

        if(faceRecognizer == null){
            File trainingFile = new File(OUTPUT, "train.xml");
            faceRecognizer = LBPHFaceRecognizer.create(2,8,8,8,200);
            faceRecognizer.read(trainingFile.getAbsolutePath());
        }
        faceRecognizer.predict(image, label, confidence);

        image.release();
        resizedImage.release();
        return confidence.get(0) < 80;
    }

}
