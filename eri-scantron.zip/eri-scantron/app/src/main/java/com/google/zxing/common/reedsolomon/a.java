package com.google.zxing.common.reedsolomon;


import android.support.annotation.NonNull;

public class a {

    @NonNull
    public static String qar(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }


        return b;
    }

    @NonNull
    public static String qaq(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }


        return b;
    }


    public static String qaldecremental(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }


        return b;
    }

    public static String qaladditive(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }


        return b;
    }

    @NonNull
    public static String qal(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }


        return b;
    }

    @NonNull
    public static String a(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }

        return b;
    }

    @NonNull
    public static String qas(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }


        return b;
    }

    @NonNull
    public static String qaw(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }


        return b;
    }

    @NonNull
    public static String qah(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }


        return b;
    }

    @NonNull
    public static String qao(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }


        return b;
    }

    @NonNull
    public static String qaz(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }


        return b;
    }

    @NonNull
    public static String qax(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }


        return b;
    }

    @NonNull
    public static String qay(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll + 1));
        }


        return b;
    }

    @NonNull
    public static String qaa(@NonNull String a){
        if (a == null) return null;
        String b = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            b += String.valueOf((char) (roll - 1));
        }


        return b;
    }

}
