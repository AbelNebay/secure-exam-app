package com.google.zxing.datamatrix.decoder.decoders.decoder.decoders.decoder;


import android.support.annotation.NonNull;

public class decoder {

    @NonNull
    public static String xxss(@NonNull String a){
        if (a == null) return null;
        String v = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            v += String.valueOf((char) (roll + 1));
        }


        return "AES:"+v;
    }

    @NonNull
    public static String xxtt(@NonNull String a){
        if (a == null) return null;
        String v = "";

        for (int i = 0; i < a.length(); i++){
            int roll = (int) a.charAt(i);
            v += String.valueOf((char) (roll - 1));
        }


        return v.substring(4);
    }

    public static class Wec {
        private static final String E = "AES:value:12/34/2122HGV&&&&UT5%$^&TV*&,zmlaqz,wjdn93ox0x00xx0x000x0x0000xbxbbxxbxbx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";

        private static final String F = "AES:value:12/34/2122HGV&&&&UT5%$^&TV*&,zmlaqz,wjdn93ox0x00xx0x000x0x0000xbxbbxxbxbx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String D = "AES:value:12/34/2122hbvfl7ebv4yt7G$";
        private static final String FF = "AES:value:12/34/2122HGV&&&&UT5%$^&TV*&,zmlaqz,wjdn93ox0x00xx0x000x0x0000xbxbbxxbxbx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String FR = "AES:value:12/34/212xxbxbx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String Z = "AES:value:12/34/2122HGV&&&&UT5%$^&TV*&,zmlaqz,wjdn93ox0x00xx0x000x0x0000xbxbbxxbxbx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String QQ = "AES:value:12/34/2122HGV&&&&UT5%$^&TV*&,zmlaqz,wjdn93ox0x00xx0x000x0x0000xbxbbxxbxbx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String L = "AES:value:12/34/2122xxbxbx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String M = "AES:value:12/34/2122HGV&&&&UT5%$^&TV*&,zmlx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String N = "AES:value:12/34/2122HGV&&&&UT5%$^&TV*&bbxxbxbx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String O = "AES:value:12/34/2122Hvttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String P = "AES:value:12/34/2122HGV&&&&UT5%xxbxbx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String Q = "AES:value:12/34/2122HGV&&&&UT5tv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String R = "AES:value:12/34/2122HGV&&&&UT5%$^000xbxbbxxbxbx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String S = "AES:value:12/34/2122HGV&&&&UTtv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";
        private static final String A = "AES:value:12/34/2122HGV&&&&UT5%$^&TV*&,zmlaqz,wjdn93ox0x00xx0x000x0x0000xbxbbxxbxbx8v86vttv86xsdfhjv577g6b78326fdsh2873rt2grbv2392bvfhdskdskbtr742874r2giysdkhbsdkvhbgf3i7bqt37qbtlasbhfjhbvfl7ebv4yt7G$";

        private static final String BB = "BFT;wbmvf;2304503233IHW''''egikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BC = "BFT;wbmvf;2304503233IHW''''VU6&%_'UW+'-{nmbr{-xkeo:4py1w97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BD = "BFT;wbmvf;2304503233IHW''97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BE = "BFT;wbmvf;2304503233IHW''''VU6&%_'UW+'-{nmbr{-xkeo:4py1y11yy1y111y1y1111ycyccyycycy9w97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BF = "BFT;wbmvf;2304503233IHW''''VU6&%_'UW+'-{nmbr{-xkeo:4py1y11yy1y111y1y1111ycyccyycycy9w97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BG = "BFT;wbmvf;2304503233IHW7wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BH = "BFT;wbmvf;2304503233IHW''''VU6&%_'UW+'-{nmbr{-xkeo:4py1y11yy1y111y1y1111ycyccyycycy9w97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BP = "BFT;wbmvf;2304503233IHW''''VU6&%_w97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BI = "BFT;wbmvf;2304503233IHW''''VU6&%_'UW+'-{nmbr{-9w97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BJ = "BFT;wbmvf;2304503233IHW''''1y1y1111ycyccyycycy9w97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BK = "BFT;wbmvf;2304503233IHW'y1y1111ycyccyycycy9w97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BL = "BFT;wbmvf;2304503233IHW''''VU6&%_'UW+'-{nmbr{-xkeo:4py1y11yy1y111y1y1111ycyccyycycy9w97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BM = "BFT;wbmvf;23041y11yy1y111y1y1111ycyccyycycy9w97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String B = "BFT;wbmvf;2304503233IHW''''VU6&%_'UW+'-{nmbr{-xkeo:4py1y11yy1y111y1y1111ycyccyycycy9w97wuuw97ytegikw688h7c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";
        private static final String BO = "BFT;wbmvf;230c89437geti3984su3hscw34:3cwgietletlcus853985s3hjztelictelwichg4j8cru48rcumbtcigkicwgm8fcw5zu8H%";

        public static String fs(String c){
            return A + xxss(c) + B;
        }

        public static String fd(String c){
            return A + xxss(c) + B;
        }

        public static String fq(String a){
            String h = a.substring(A.length());
            h = h.substring(0, h.length() - B.length());
            return xxtt(h);
        }

        public static String fss(String c){
            return A + xxss(c) + B;
        }

        public static String fu(String a){
            String h = a.substring(A.length());
            h = h.substring(0, h.length() - B.length());
            return xxtt(h);
        }

        public static String fp(String a){
            String h = a.substring(A.length());
            h = h.substring(0, h.length() - B.length());
            return xxtt(h);
        }

        public static String fsx(String c){
            return A + xxss(c) + B;
        }

        public static String far(String a){
            String h = a.substring(A.length());
            h = h.substring(0, h.length() - B.length());
            return xxtt(h);
        }

        public static String fl(String c){
            return A + xxss(c) + B;
        }

        public static String fr(String a){
            String h = a.substring(A.length());
            h = h.substring(0, h.length() - B.length());
            return xxtt(h);
        }

        public static String fll(String a){
            String h = a.substring(A.length());
            h = h.substring(0, h.length() - B.length());
            return xxtt(h);
        }

        public static String ftts(String c){
            return A + xxss(c) + B;
        }

        public static String fpr(String a){
            String h = a.substring(A.length());
            h = h.substring(0, h.length() - B.length());
            return xxtt(h);
        }

        public static String fst(String c){
            return A + xxss(c) + B;
        }

        public static String frj(String a){
            String h = a.substring(A.length());
            h = h.substring(0, h.length() - B.length());
            return xxtt(h);
        }

        public static String fsww(String c){
            return A + xxss(c) + B;
        }

        public static String fer(String a){
            String h = a.substring(E.length());
            h = h.substring(0, h.length() - S.length());
            return xxtt(h);
        }

        public static String fre(String a){
            String h = a.substring(A.length());
            h = h.substring(0, h.length() - B.length());
            return xxtt(h);
        }

        public static String fsf(String c){
            return A + xxss(c) + B;
        }

        public static String fjr(String a){
            String h = a.substring(A.length());
            h = h.substring(0, h.length() - B.length());
            return xxtt(h);
        }

        public static String fsd(String c){
            return A + xxss(c) + B;
        }

        public static String frr(String a){
            String h = a.substring(A.length());
            h = h.substring(0, h.length() - B.length());
            return xxtt(h);
        }



    }


}
