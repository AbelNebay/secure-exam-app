package com.google.zxing.pdf417.detector.a;


class cc {
    public String name;
    public String seek_value;

    public cc(String name, String seek_value) {
        this.name = name;
        this.seek_value = seek_value;
    }
}
