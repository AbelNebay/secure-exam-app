package com.google.zxing.datamatrix.datamatrix.datamatrix.datamatrix.datamatrix;


public class datamatrix {


    public static int a = 2;
    public static int b = 5;
    public static int c = 2;
    public static int d = 6;
    public static int e = 1;
    public static int f = 3;
    public static int g = 4;
    public static int h = 8;
    public static int anInt = 1;
    public static int aJ = 30;
    public static int ak = 523;
    public static int al = 22365;
    public static int m = 252;
    public static int anInt1 = 252;
    public static int o = 226;
    public static int p = 225;
    public static int q = 2632;
    public static int r = 2654;
    public static int s = 5472;
    public static int t = 462;
    public static int u = 2326;
    public static int v = 12462;
    public static int w = 30;
    public static int y = 682;
    public static int z = 2162;
    public static int zz = 2172;
    public static int aa = 2472;
    public static int ab = 5842;


}
