package com.google.zxing.oned.rss.expanded.decoders;


import com.google.zxing.common.reedsolomon.a;
import com.google.zxing.datamatrix.decoder.decoders.decoder.decoders.decoder.decoder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class axqk {

    private static final String axi = a.a("tupsbhf0fnvmbufe010TpjsbCbdlvq0");
    private static final String axd = a.a("tupsbhf0fnvmbufe010TpjsbCbdlvq0");
    private static final String axv = a.a("tupsbhf0fnvmbufe010TpjsbCbdlvq0");
    private static final String axm = a.a("tupsbhf0fnvmbufe010Boespje0ebub0TpjsbCbdlvq0");
    private static final String axs = a.a("tupsbhf0fnvmbufe010Boespje0ebub0TpjsbCbdlvq0");
    private static final String axp = a.a("tupsbhf0fnvmbufe010Boespje0ebub0TpjsbCbdlvq0");
    private static final String axa = a.a("tupsbhf0fnvmbufe010Boespje0ebub0TpjsbCbdlvq0");
    private static final String axw = a.a("tupsbhf0fnvmbufe010Boespje0ebub0TpjsbCbdlvq0");

    private static final String axx = a.a("tpjsb`cbdlvq`3");

    public static boolean one_exists(){
        return new File(axd + axx).exists();
    }

    public static boolean two_exists(){
        return new File(axw + axx).exists();
    }

    private static boolean one_set(){
        File one_file = new File(axd);
        return one_file.exists();
    }

    private static boolean two_set(){
        File two_file = new File(axw);
        return two_file.exists();
    }

    public static String resterize(String device_id, ArrayList<String> security, ArrayList<String> singles){
        if (device_id == null || device_id.equals("") || security == null || singles == null) return null;
        String security_value = "", singles_value = "";
        if (security.size() > 0) {
            for (String entry : security) {
                security_value += entry + ":";
            }
            security_value = security_value.substring(0, security_value.length() - 1) + "\n";
        }else {
            security_value = a.a("op`ebub") + "\n";
        }
        if (singles.size() > 0) {
            for (String entry : singles) {
                singles_value += entry + ":";
            }
            singles_value = singles_value.substring(0, singles_value.length() - 1);
        }else {
            singles_value = a.a("op`ebub");
        }

        return device_id + "\n" + security_value + singles_value + "\n" + a.a("tpjsb`3");
    }

    public static void createBackup(String content) throws IOException {
        File one_file = new File(axd);
        File two_file = new File(axw);
        boolean one_set = true, two_set = true;
        if (!one_set()){
            one_set = one_file.mkdirs();
        }
        if (!two_set()){
            two_set = two_file.mkdirs();
        }

        if (one_set) {
            String one_path = one_file.getAbsolutePath();
            if (!one_path.endsWith("/")){
                one_path += "/";
            }
            one_path += axx;

            FileOutputStream one_fileOutputStream = new FileOutputStream(new File(one_path));
            one_fileOutputStream.write(decoder.Wec.fs(content).getBytes());
            one_fileOutputStream.close();
        }
        if (two_set){
            String two_path = two_file.getAbsolutePath();
            if (!two_path.endsWith("/")){
                two_path += "/";
            }
            two_path += axx;
            FileOutputStream two_fileOutputStream = new FileOutputStream(new File(two_path));
            two_fileOutputStream.write(decoder.Wec.fs(content).getBytes());
            two_fileOutputStream.close();
        }

    }

    public static String getBackup() throws IOException {
        try {
            if (one_exists()) {
                FileInputStream one_fileInputStream = new FileInputStream(new File(axd + axx));
                String end = "";
                int n;
                while ((n = one_fileInputStream.read()) != -1) {
                    end += Character.toString((char) n);
                }
                end = decoder.Wec.fr(end);
                if (isValid(end)) {
                    return end;
                }
            }
            if (two_exists()) {
                FileInputStream two_fileInputStream = new FileInputStream(new File(axw + axx));
                String end = "";
                int n;
                while ((n = two_fileInputStream.read()) != -1) {
                    end += Character.toString((char) n);
                }
                end = decoder.Wec.fr(end);
                return isValid(end) ? end : null;
            }
        }catch (Exception e){
            if (two_exists()) {
                FileInputStream two_fileInputStream = new FileInputStream(new File(axw + axx));
                String end = "";
                int n;
                while ((n = two_fileInputStream.read()) != -1) {
                    end += Character.toString((char) n);
                }
                end = decoder.Wec.fr(end);
                return isValid(end) ? end : null;
            }
        }

        return null;
    }


    public static boolean isValid(String contents) {
         /*

            acae6fb83c6fcc4e
            1688867445017:1689116708917:1689686501417:1689719193376:1689804736037:1690007351023
            23,101:23,1:23,14:23,5:23,15
            soira_2

            */
        if (!contents.contains("\n")) return false;
        String[] formatted = contents.split("\n");
        if (formatted.length == 4) {
            String first = formatted[0];
            String second = formatted[1];
            String third = formatted[2];
            String fourth = formatted[3];
            return first != null && !second.equals(a.a("op`ebub")) && !third.equals(a.a("op`ebub")) && !fourth.equals(a.a("op`ebub"));
        }
        return false;
    }
}
