package er.leafpedia.barka.decode;

import android.graphics.Bitmap;

public abstract class LuminanceSource extends com.google.zxing.LuminanceSource {

    LuminanceSource(int width, int height) {
super(width, height);
}

    public abstract byte[] getMatrix();

    public abstract byte[] getRow(int y, byte[] row);

    public abstract Bitmap renderCroppedGreyScaleBitmap();
}
 