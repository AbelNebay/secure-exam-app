package er.leafpedia.barka;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.zxing.Result;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.reedsolomon.a;
import com.soira.eri_scantron.R;

import er.leafpedia.barka.camera.CameraManager;
import er.leafpedia.barka.camera.PreviewFrameShotListener;
import er.leafpedia.barka.camera.Size;
import er.leafpedia.barka.decode.DecodeListener;
import er.leafpedia.barka.decode.DecodeThread;
import er.leafpedia.barka.decode.LuminanceSource;
import er.leafpedia.barka.decode.PlanarYUVLuminanceSource;
import er.leafpedia.barka.decode.RGBLuminanceSource;
import er.leafpedia.barka.view.CaptureView;


public class CaptureActivity extends Activity implements SurfaceHolder.Callback, PreviewFrameShotListener, DecodeListener, OnClickListener {
    private static final long VIBRATE_DURATION = 200L;
    private static final int REQUEST_CODE_ALBUM = 0;
    public static final String EXTRA_RESULT = "result";
    private CaptureView captureView;
    private CameraManager mCameraManager;
    private DecodeThread mDecodeThread;
    private Rect previewFrameRect = null;
    private boolean isDecoding = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capture);

        SurfaceView previewSv = (SurfaceView) findViewById(R.id.sv_preview);
        captureView = (CaptureView) findViewById(R.id.cv_capture);
        ImageView backBtn = (ImageView) findViewById(R.id.btn_back);

        backBtn.setOnClickListener(this);
        previewSv.getHolder().addCallback(this);
        mCameraManager = new CameraManager(this);
        mCameraManager.setPreviewFrameShotListener(this);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        mCameraManager.initCamera(holder);
        if (!mCameraManager.isCameraAvailable()) {
            Toast.makeText(CaptureActivity.this, "Capture Frame Failed", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        mCameraManager.startPreview();
        if (!isDecoding) {
            mCameraManager.requestPreviewFrameShot();
        }
    }


    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        mCameraManager.stopPreview();
        if (mDecodeThread != null) {
            mDecodeThread.cancel();
        }
        mCameraManager.release();
    }

    @Override
    public void onPreviewFrame(byte[] data, Size dataSize) {
        if (mDecodeThread != null) {
            mDecodeThread.cancel();
        }
        if (previewFrameRect == null) {
            previewFrameRect = mCameraManager.getPreviewFrameRect(captureView.getFrameRect());
        }
        PlanarYUVLuminanceSource luminanceSource = new PlanarYUVLuminanceSource(data, dataSize, previewFrameRect);
        mDecodeThread = new DecodeThread(luminanceSource, CaptureActivity.this);
        isDecoding = true;
        mDecodeThread.execute();
    }

    @Override
    public void onDecodeSuccess(Result result, LuminanceSource source) {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        vibrator.vibrate(VIBRATE_DURATION);
        isDecoding = false;
        Intent resultData = new Intent();
        String value = a.a(result.getText());
        resultData.putExtra(EXTRA_RESULT, value);
        setResult(RESULT_OK, resultData);
        finish();
    }

    @Override
    public void onDecodeFailed(LuminanceSource source) {
        if (source instanceof RGBLuminanceSource) {
            Toast.makeText(CaptureActivity.this, "Capture Decode Failed", Toast.LENGTH_SHORT).show();
        }
        isDecoding = false;
        mCameraManager.requestPreviewFrameShot();
    }

    @Override
    public void foundPossibleResultPoint(ResultPoint point) {
        captureView.addPossibleResultPoint(point);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_back:
                finish();
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_ALBUM && resultCode == RESULT_OK && data != null) {
        //    Bitmap cameraBitmap = null;
        //    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
        //    String path = .getPath(CaptureActivity.this, data.getData());
        //    cameraBitmap = DocumentUtil.getBitmap(path);
        //    } else {
        //    // Not supported in SDK lower that KitKat
        //    }
        //    if (cameraBitmap != null) {
        //    if (mDecodeThread != null) {
        //    mDecodeThread.cancel();
         }
        //    int width = cameraBitmap.getWidth();
        //    int height = cameraBitmap.getHeight();
        //    int[] pixels = new int[width * height];
        //    cameraBitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        //    RGBLuminanceSource luminanceSource = new RGBLuminanceSource(pixels, new Size(width, height));
        //    mDecodeThread = new DecodeThread(luminanceSource, CaptureActivity.this);
        //    isDecoding = true;
        //    mDecodeThread.execute();
        //}
        //}
    }
}
