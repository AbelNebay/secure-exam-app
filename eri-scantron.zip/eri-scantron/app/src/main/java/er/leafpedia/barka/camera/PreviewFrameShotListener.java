package er.leafpedia.barka.camera;
public interface PreviewFrameShotListener {
public void onPreviewFrame(byte[] data, Size frameSize);

    // Pax - the only thing I need
}
 