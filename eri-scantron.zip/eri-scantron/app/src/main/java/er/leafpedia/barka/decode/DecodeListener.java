package er.leafpedia.barka.decode;

import com.google.zxing.Result;
import com.google.zxing.ResultPointCallback;

public interface DecodeListener extends ResultPointCallback {

    void onDecodeSuccess(Result result, LuminanceSource source);

    void onDecodeFailed(LuminanceSource source);
}
